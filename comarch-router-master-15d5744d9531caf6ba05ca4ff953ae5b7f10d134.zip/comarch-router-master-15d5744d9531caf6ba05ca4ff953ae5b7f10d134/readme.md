# Требования

- Java
- Maven

# Сборка и деплой приложения

- Необходимо выполнить команду `sh operations/deploy_war.sh production`.


