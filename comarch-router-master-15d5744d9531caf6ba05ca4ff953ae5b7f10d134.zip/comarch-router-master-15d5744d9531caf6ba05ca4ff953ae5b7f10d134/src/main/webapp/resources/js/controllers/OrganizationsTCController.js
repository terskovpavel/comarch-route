var app = angular.module('web_service_xml', ['ngResource', 'xeditable', 'ui.bootstrap']);
app.run(function (editableOptions) {
    editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});

var apiAll = '/organization/all/tc';
var apiUrl = '/organization/tc/page/';

app.controller('OrgCtrl', function ($scope, $filter, $http) {

    $scope.tableLoaded = false;

    $scope.vm = {
        pagination: {
            currentPage: 1,
            itemPerPage: 10,
            displaying: true
        }
    }


    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    //Получение всех Организаций
    $http.get(apiAll).success(function (orgs) {
        $scope.allOrgs = orgs;
        $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageOrgs) {
            console.log("pageOrgs " + pageOrgs);
            $scope.vm.pagination.totalItems = orgs.length;
            $scope.orgs = pageOrgs;
            $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
            $scope.tableLoaded = true;
        });
    });
    //Вызывается при смене номера страницы
    $scope.pageChanged = function () {
        $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageOrgs) {
            console.log("pageOrgs " + pageOrgs);
            $scope.orgs = pageOrgs;
        });
    }
    //Сохранение объекта в базу
    $scope.saveObject = function (data, org, id) {
        if (id && data.headId && data.headId == id) {
            toastr.error("Организация не может ссылаться на саму себя.");
            return "";
        }
        if (data.headId) {
            for (var i = 0; i < $scope.orgs.length; i++) {
                if ($scope.orgs[i].id == data.headId) {
                    if ($scope.orgs[i].headId) {
                        toastr.error("Организация не может иметь во главе филиал.");
                        return "";
                    }
                }
            }

        }
        if (!data.name) {
            toastr.error("Имя не должно быть пустым.");
            return "";
        }
        if (!data.gln) {
            toastr.error("Gln не должен быть пустым.");
            return "";
        }
        data.orgType = 'TC';
        data.id = id;
        return $http.post('/organization/update', data).success(function (response) {
            org.id = response.id;

            //Получение всех Организаций
            $http.get(apiAll).success(function (orgs) {
                $scope.allOrgs = orgs;
                $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageOrgs) {
                    console.log("pageOrgs " + pageOrgs);
                    $scope.vm.pagination.totalItems = orgs.length;
                    $scope.orgs = pageOrgs;
                    $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
                    $scope.tableLoaded = true;
                });
            });
        });
    };

    //Отображение имя поставщика из ftp
    $scope.showHeadName = function (org) {
        if (org.headId == '-1' || org.headId == null) {
            return "Нет";
        }
        for (var i = 0; i < $scope.allOrgs.length; i++) {
            if (org.headId == $scope.allOrgs[i].id) {
                return $scope.allOrgs[i].name;
            }
        }
        return "Нет";
    }

    function findById(id) {
        for (var i = 0; i < $scope.orgs.length; i++) {
            if ($scope.orgs[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    $scope.cancelOrg = function (rowform, id) {
        rowform.$cancel();
        if (!id) {
            $scope.orgs.splice(-1, 1)
        }
    }

    $scope.orgTypes = ['SUPPLIER', 'TC'];

    //Удаление объекта из таблицы
    $scope.removeObject = function (id) {
        var index = findById(id);
        var elem = $scope.orgs[index];
        $scope.orgs.splice(index, 1);
        $http.post('/organization/delete/' + elem.id);
    };

    //Добавление объекта в таблицу
    $scope.addObject = function () {
        $scope.inserted = {
            name: '',
            gln: '',
            orgType: '',
            headId: null
        };
        $scope.orgs.push($scope.inserted);
    };

});
