var app = angular.module('web_service_xml', ['ngResource', 'xeditable']);
app.run(function (editableOptions) {
    editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});

var apiUrl = '/organization/all';


app.controller('OrgCreateRouteCtrl', function ($scope, $filter, $http) {

    $scope.tableLoaded = false;

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    $('#multiple_select').multipleSelect();

    $scope.tcs = [];
    $scope.suppliers = [];
    $scope.routes = [];
    $scope.tcValue = "";
    $scope.supplierValue = "";

    $scope.tcBranches = [];
    //$scope.supplierBranches = [];
    $scope.documentType = "";

    //Initializing orgs
    $http.get(apiUrl).success(function (orgs) {
        console.log("Orgs create" + orgs);
        for (var i = 0; i < orgs.length; i++) {
            var org = {id: orgs[i].id, name: orgs[i].name};
            var orgType = orgs[i].orgType;
            if (orgType == 'TC') {
                $scope.tcs.push(org);
            }
            if (orgType == 'SUPPLIER' && !orgs[i].headId) {
                $scope.suppliers.push(org);
            }
        }
        $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
        $scope.tableLoaded = true;
    });


    $scope.changeTcSelect = function () {
        $scope.tcBranches = [];
        $http.get("/organization/all/" + $scope.tcValue).success(function (tcBranches) {
            for (var j = 0; j < tcBranches.length; j++) {
                var tcBranch = {id: tcBranches[j].id, gln: tcBranches[j].gln};
                $scope.tcBranches.push(tcBranch);
            }
        });
    }

    $scope.uploadExcel = function (orgRouteId) {
        var excel = $scope.excel;

        console.log('file is ');
        console.dir(excel);

        var uploadUrl = "/orgRoute/excel/parseRoutes/";
        return uploadFileToUrl(excel, uploadUrl, orgRouteId);
    }

    function uploadFileToUrl(file, uploadUrl, orgRouteId) {
        var fd = new FormData();
        fd.append('file', file);

        return $http.post(uploadUrl + orgRouteId, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        });
    }

    //$scope.changeSupplierValue = function () {
    //    $scope.supplierBranches = [];
    //    $http.get("/organization/all/" + $scope.supplierValue).success(function (supplierBranches) {
    //        for (var k = 0; k < supplierBranches.length; k++) {
    //            var supplierBranch = {id: supplierBranches[k].id, gln: supplierBranches[k].gln};
    //            $scope.supplierBranches.push(supplierBranch);
    //        }
    //    });
    //}

    $scope.uploadObject = function () {
        if ((!$scope.routes || $scope.routes.length == 0) && !$scope.excel) {
            toastr.error("Добавьте хотя бы 1 подмаршрут");
            return;
        }
        var selecteds = $('#multiple_select').multipleSelect('getSelects');
        if (!selecteds || selecteds.length == 0) {
            toastr.error("Выберите типы документов.");
            return;
        }
        var request = {};
        request.tcId = $scope.tcValue;
        request.supplierId = $scope.supplierValue;
        request.routes = $scope.routes;
        request.docTypes = selecteds;
        return $http.post('/orgRoute/create', request).success(function (response) {
            if ($scope.excel) {
                $scope.uploadExcel(response.id)
                    .success(function () {
                        document.location.href = "/org_route";
                    });
            } else {
                document.location.href = "/org_route";
            }
        });
    }


    $scope.cancelCreateRoute = function (rowform) {
        rowform.$cancel();
        $scope.routes.splice(-1, 1)
    }

    $scope.saveObject = function (data, index) {
        //$scope.user not updated yet
        if (!data.sender) {
            toastr.error("Sender не должен быть пустым");
            return "";
        }
        if (!data.sender) {
            toastr.error("Sender не должен быть пустым");
            return "";
        }
        if (!data.deliveryPoint) {
            toastr.error("Delivery point не должен быть пустым");
            return "";
        }
        if (!data.routingSender) {
            toastr.error("Routing sender не должен быть пустым");
            return "";
        }
        if (!data.receiver) {
            toastr.error("Receiver не должен быть пустым");
            return "";
        }
        $scope.routes[index].sender = data.sender;
        $scope.routes[index].deliveryPoint = data.deliveryPoint;
    };

    //remove object
    $scope.removeObject = function (index) {
        $scope.routes.splice(index, 1);
    };

    //add object
    $scope.addObject = function () {
        if (!$scope.tcValue) {
            toastr.error("Сначала выберите головной офис нужной Торговой сети")
            return;
        }
        if (!$scope.supplierValue) {
            toastr.error("Сначала выберите головной офис поставщика")
            return;
        }
        $scope.inserted = {
            sender: '',
            deliveryPoint: '',
            routingSender: '',
            receiver: '',
        };
        $scope.routes.push($scope.inserted);
    };
});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);
