var app = angular.module('web_service_xml', ['ngResource', 'xeditable']);
app.run(function (editableOptions) {
    editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});
var apiUrl = '/users/all';

app.controller('UsersCtrl', function ($scope, $filter, $http) {

    $scope.tableLoaded = true;

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    $scope.users = [];

    //Initializing users
    $http.get(apiUrl).success(function (users) {
        console.log("Users " + users);
        $scope.users = users;
        $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
        $scope.tableLoaded = true;
    });

    $scope.saveObject = function (data, user, id) {
        //$scope.user not updated yet
        data.id = id;
        if (!data.username) {
            toastr.error("Логин не должен быть пустым");
            return "";
        }
        if (!data.password) {
            toastr.error("Пароль не должен быть пустым");
            return "";
        }
        return $http.post('/registration', data).success(function (response) {
            user.id = response.t.id;
            user.password = response.t.password;
            data.password = response.t.password;

        });
    };

    function findById(id) {
        for (var i = 0; i < $scope.users.length; i++) {
            if ($scope.users[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    $scope.cancelUser = function (rowform, id) {
        rowform.$cancel();
        if (!id) {
            $scope.users.splice(-1, 1)
        }

    }


    //remove object
    $scope.removeObject = function (id) {
        var index = findById(id);
        var elem = $scope.users[index];
        $scope.users.splice(index, 1);
        $http.post('/users/delete/' + elem.id);
    };

    $scope.cancel = function (rowform, index) {
        console.log($scope.users.length)
        $scope.users.slice(index, 1);
        rowform.$cancel();
    }

    //add object
    $scope.addObject = function () {
        $scope.inserted = {
            login: '',
            password: ''
        };
        $scope.users.push($scope.inserted);
    };
});
