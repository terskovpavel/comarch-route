var app = angular.module('web_service_xml', ['ngResource', 'xeditable', 'ui.bootstrap']);
app.run(function (editableOptions) {
    editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});
var apiAll = '/ftp/all';
var apiUrl = '/ftp/page/';

app.controller('FTPCtrl', function ($scope, $filter, $http) {
    $scope.tableLoaded = false;

    $scope.vm = {
        pagination: {
            currentPage: 1,
            itemPerPage: 10,
            displaying: true
        }
    }


    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    $scope.branches = [];

    $http.get("/organization/suppliers/branches").success(function (branches) {
        $scope.branches = branches;
    });

    //Получение всех FTP
    $http.get(apiAll).success(function (ftps) {
        $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageFtps) {
            console.log("pageFtps " + pageFtps);
            $scope.vm.pagination.totalItems = ftps.length;
            $scope.ftps = pageFtps;
            $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
            $scope.tableLoaded = true;
        });
    });

    //Вызывается при смене номера страницы
    $scope.pageChanged = function () {
        $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageFtps) {
            console.log("pageFtps " + pageFtps);
            $scope.ftps = pageFtps;
        });
    }

    //Сохранение объекта в базу
    $scope.saveObject = function (data, id) {
        //$scope.ftp not updated yet
        data.id = id;
        if (!data.supplierId) {
            toastr.error("Gln поставщика не должен быть пустым");
            return "";
        }
        if (!data.ip) {
            toastr.error("Ip не должен быть пустым");
            return "";
        }
        if (!data.department) {
            toastr.error("Подразделение не должен быть пустым");
            return "";
        }
        if (!data.login) {
            toastr.error("Логин не должен быть пустым");
            return "";
        }

        if (!data.password) {
            toastr.error("Пароль не должен быть пустым");
            return "";
        }
        return $http.post('/ftp/update', data);
    };

    function findById(id) {
        for (var i = 0; i < $scope.ftps.length; i++) {
            if ($scope.ftps[i].id == id) {
                return i;
            }
        }
        return -1;
    }

    //Отображение имя поставщика из ftp
    $scope.showOrgName = function (ftp) {
        if (!ftp) {
            return
        }
        if (ftp.supplierId == '-1' || ftp.supplierId == null) {
            return "";
        }
        for (var i = 0; i < $scope.branches.length; i++) {
            if (ftp.supplierId == $scope.branches[i].id) {
                return $scope.branches[i].name;
            }
        }
        return "Нет";
    }

    $scope.cancelFtp = function (rowform, id) {
        rowform.$cancel();
        if (!id) {
            $scope.ftps.splice(-1, 1)
        }
    }

    //Удаление объекта из таблицы
    $scope.removeObject = function (id) {
        var index = findById(id);
        var elem = $scope.ftps[index];
        $scope.ftps.splice(index, 1);
        $http.post('/ftp/delete/' + elem.id);
    };


    //Добавление объекта в таблицу
    $scope.addObject = function () {
        $scope.inserted = {
            gln: '',
            ip: '',
            department: '',
            supplierId: '',
            login: '',
            password: ''
        };
        $scope.ftps.push($scope.inserted);
    };
});
