app = angular.module('web_service_xml', ['ngResource', 'ui.bootstrap']);
angular.module("web_service_xml").controller('TrackInfoCtrl', ['$scope', '$http',
    function ($scope, $http) {
        //Pagination parameters
        var apiUrl = '/trackInfo/page/';
        var apiCount = '/trackInfo/count'
        var apiFilterCount = '/trackInfo/page/count'
        $scope.tableLoaded = false;
        $scope.vm = {
            pagination: {
                currentPage: 1,
                itemPerPage: 10,
                displaying: true
            }
        }


        //Initializing tracks
        $http.get(apiCount).success(function (data) {
            $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1)).success(function (pageTrackings) {
                console.log("Trackings " + pageTrackings);
                $scope.trackings = pageTrackings;
                $scope.vm.pagination.totalItems = data;
                $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
                $scope.tableLoaded = true;
            });
        });

        $scope.clear = function () {
            $scope.documentType = "";
            $scope.documentStatus = "";
            $scope.nome = "";
            $scope.receiverGln = "";
            $scope.trackingId = "";
            $scope.startDate = "";
            $scope.endDate = "";
            $scope.doFilter();
        }

        //Called every time page changed
        $scope.pageChanged = function () {
            var params = "?";
            if ($scope.documentType) {
                params += "&docType=" + $scope.documentType;
            }
            if ($scope.documentStatus) {
                params += "&status=" + $scope.documentStatus;
            }
            if ($scope.nomer) {
                params += "&number=" + $scope.nomer;
            }
            if ($scope.receiverGln) {
                params += "&gln=" + $scope.receiverGln;
            }
            if ($scope.trackingId) {
                params += "&trackingId=" + $scope.trackingId;
            }
            if ($scope.startDate) {
                params += "&startDate=" + $scope.startDate;
            }
            if ($scope.endDate) {
                params += "&endDate=" + $scope.endDate;
            }
            $http.get(apiUrl + ($scope.vm.pagination.currentPage - 1) + params).success(function (pageTrackings) {
                console.log("Trackings " + pageTrackings);
                $scope.trackings = pageTrackings;
                $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
                $scope.tableLoaded = true;
            });
        }
        $scope.doFilter = function () {
            var params = "?";
            if ($scope.documentType) {
                params += "&docType=" + $scope.documentType;
            }
            if ($scope.documentStatus) {
                params += "&status=" + $scope.documentStatus;
            }
            if ($scope.nomer) {
                params += "&number=" + $scope.nomer;
            }
            if ($scope.receiverGln) {
                params += "&gln=" + $scope.receiverGln;
            }
            if ($scope.trackingId) {
                params += "&trackingId=" + $scope.trackingId;
            }
            if ($scope.startDate) {
                params += "&startDate=" + $scope.startDate;
            }
            if ($scope.endDate) {
                params += "&endDate=" + $scope.endDate;
            }
            $http.get(apiFilterCount + params).success(function (data) {
                $http.get(apiUrl + 0 + params).success(function (pageTrackings) {
                    console.log("Trackings " + pageTrackings);
                    $scope.trackings = pageTrackings;
                    $scope.vm.pagination.totalItems = data;
                    $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
                    $scope.tableLoaded = true;
                });
            });
        }

        $scope.showStatus = function (status) {
            if (status) {
                return "Успешно";
            }
            return "Не успешно";
        }

        $scope.showDate = function (longDate) {
            var date = moment(longDate);
            return date.format('DD-MM-YYYY HH:mm');
        }
    }]);