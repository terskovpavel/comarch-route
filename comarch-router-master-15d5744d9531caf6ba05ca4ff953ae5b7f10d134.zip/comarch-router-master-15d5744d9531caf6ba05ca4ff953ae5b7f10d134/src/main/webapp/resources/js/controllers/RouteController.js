var app = angular.module('web_service_xml', ['ngResource', 'xeditable', 'ui.bootstrap']);
app.run(function (editableOptions) {
    editableOptions.theme = 'bs3'; // bootstrap3 theme. Can be also 'bs2', 'default'
});
app.controller('RouteCtrl', function ($scope, $filter, $http) {
    var apiAll = "/route/all/";

    $scope.vm = {
        pagination: {
            currentPage: 1,
            itemPerPage: 10,
            displaying: true
        }
    }

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    var orgRouteId = window.location.pathname.split("/")[2];

    $scope.routes = [];

    $scope.tcBranches = [];
    //$scope.supplierBranches = [];

    $scope.tableLoaded = false;

    //Initializing routes
    $http.get("/orgRoute/branches/" + orgRouteId).success(function (branches) {
        console.log("branches " + branches);
        $scope.tcBranches = branches.tcs;
        //$scope.supplierBranches = branches.suppliers;

        //Initializing routes
        $http.get(apiAll + orgRouteId).success(function (routes) {
            $http.get("/route/page/" + ($scope.vm.pagination.currentPage - 1) + "/orgRoute/" + orgRouteId).success(function (pageRoutes) {
                console.log("pageRoutes " + pageRoutes);
                $scope.vm.pagination.totalItems = routes.length;
                $scope.routes = pageRoutes;
                $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
                $scope.tableLoaded = true;
            });
        });
    });

    //Called every time page changed
    $scope.pageChanged = function () {
        $http.get("/route/page/" + ($scope.vm.pagination.currentPage - 1) + "/orgRoute/" + orgRouteId).success(function (pageRoutes) {
            console.log("pageRoutes " + pageRoutes);
            $scope.routes = pageRoutes;
        });
    }

    $scope.showStub = function (stub) {
        return stub;
    }

    function findById(id) {
        for (var i = 0; i < $scope.routes.length; i++) {
            if ($scope.routes[i].id == id) {
                return i;
            }
        }
        return -1;
    }


    $scope.saveObject = function (data, id) {
        data.id = id;
        if (!data.sender) {
            toastr.error("Sender не должен быть пустым");
            return "";
        }
        if (!data.deliveryPoint) {
            toastr.error("Delivery point не должен быть пустым");
            return "";
        }
        if (!data.routingSender) {
            toastr.error("Routing sender не должен быть пустым");
            return "";
        }
        if (!data.receiver) {
            toastr.error("Receiver не должен быть пустым");
            return "";
        }
        data.orgRouteId = orgRouteId;
        return $http.post('/route/update', data);
    };

    $scope.cancelRoute = function (rowform) {
        rowform.$cancel();
        $scope.routes.splice(-1, 1)
    }

    //remove object
    $scope.removeObject = function (id) {
        var index = findById(id);
        var elem = $scope.routes[index];
        $scope.routes.splice(index, 1);
        $http.post('/route/delete/' + elem.id);
    };

    //add object
    $scope.addObject = function () {
        $scope.inserted = {
            sender: '',
            deliveryPoint: '',
            routingSender: '',
            receiver: '',
        };
        $scope.routes.push($scope.inserted);
    };
});
