var app = angular.module('web_service_xml', ['ngResource', 'ui.bootstrap','ui.select']);
var apiUrl = '/orgRoute/all';
var orgUrl = '/organization/all';
var apiPage = '/orgRoute/page/';
app.controller('OrgRouteCtrl', function ($scope, $filter, $http) {

    $scope.tableLoaded = false;

    $scope.vm = {
        pagination: {
            currentPage: 1,
            itemPerPage: 10,
            displaying: true
        }
    }

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    //Initializing orgs
    $http.get(orgUrl).success(function (orgs) {
        console.log("Orgs " + orgs);
        $scope.orgs = orgs;
        $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
        $scope.tableLoaded = true;
    });

    //Initializing orgRoutes
    $http.get(apiUrl).success(function (orgRoutes) {
        $http.get(apiPage + ($scope.vm.pagination.currentPage - 1)).success(function (pageOrgRoutes) {
            console.log("pageOrgRoutes " + pageOrgRoutes);
            $scope.vm.pagination.totalItems = orgRoutes.length;
            $scope.orgRoutes = pageOrgRoutes;
            $("#data_table").removeClass("hidetable").addClass("table table-striped table-hover")
            $scope.tableLoaded = true;
        });
    });

    //Called every time page changed
    $scope.pageChanged = function () {
        $http.get(apiPage + ($scope.vm.pagination.currentPage - 1)).success(function (pageOrgRoutes) {
            console.log("pageOrgRoutes " + pageOrgRoutes);
            $scope.orgRoutes = pageOrgRoutes;
        });
    }


    $scope.validateOrgs = function () {
        if ($scope.orgs.length == 0) {
            toastr.error("Сначала нужно добавить организации и их филиалы");
            return;
        }
        document.location.href = "/org_route_create";
    }

    $scope.showOrgName = function (id) {
        if (!id || !$scope.orgs)return;
        for (var i = 0; i < $scope.orgs.length; i++) {
            if (id == $scope.orgs[i].id) {
                return $scope.orgs[i].name;
            }
        }
        return '';
    }

    $scope.showDate = function (longDate) {
        var date = moment(longDate);
        return date.format('DD-MM-YYYY HH:mm');
    }

    function findById(id) {
        for (var i = 0; i < $scope.orgRoutes.length; i++) {
            if ($scope.orgRoutes[i].id == id) {
                return i;
            }
        }
        return -1;
    }


    //remove object
    $scope.removeObject = function (id) {
        var index = findById(id);
        var elem = $scope.orgRoutes[index];
        $scope.orgRoutes.splice(index, 1);
        $http.post('/orgRoute/delete/' + elem.id);
    };

});
