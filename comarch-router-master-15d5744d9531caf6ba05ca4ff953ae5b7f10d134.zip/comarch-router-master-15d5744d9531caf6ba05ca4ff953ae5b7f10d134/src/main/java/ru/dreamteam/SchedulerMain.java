package ru.dreamteam;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Класс для тестов
 */
public class SchedulerMain {

    public static void main(String[] args) throws InterruptedException {
        SchedulerMain schedulerMain = new SchedulerMain();
        schedulerMain.startExample();
    }

    public void startExample() throws InterruptedException {

        // Variables
        int delay = 0;
        int periodBefore = 1;
        int periodAfter = 5;

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        Task task = new Task();
        // Start task with period 1 second
        ScheduledFuture<?> scheduledFuture =
                service.scheduleAtFixedRate(task, delay, periodBefore, TimeUnit.SECONDS);

        Thread.sleep(5000);
        System.out.println("new Thread");
        // Restart task with period 5 seconds
        scheduledFuture.cancel(true);
        service.scheduleAtFixedRate(task, delay, periodAfter, TimeUnit.SECONDS);
    }

    class Task implements Runnable {
        @Override
        public void run() {
            System.out.println("Hello, world!");
        }
    }
}
