package ru.dreamteam;

import ru.dreamteam.model.soap.DocumentStatusResponse;
import ru.dreamteam.model.soap.receive.DocumentOrder;
import ru.dreamteam.model.soap.MailboxResponse;
import ru.dreamteam.model.soap.RelationResponse;
import ru.dreamteam.model.soap.receive.DocumentRecAdv;
import ru.dreamteam.service.SoapService;
import ru.dreamteam.service.impl.SoapServiceImpl;

/**
 * Класс для тестов
 */
public class SoapServiceMain {

    public static void main(String[] args) throws Exception {
//        makeRelationshipsRequest();
        makeListPBRequest();
        makeListMBRequest();
        makeReceiveRequestForDocumentOrder();
        makeReceiveRequestForDocumentRecAdv();
        makeSendRequest();
    }

    private static void makeRelationshipsRequest() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String timeout = "1000";

        SoapService soapService = new SoapServiceImpl();
        RelationResponse responseRelationships = soapService.sendRelationshipsRequest(name, password, timeout);
    }

    private static void makeListPBRequest() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String timeout = "1000";
        String partnerIln = "2000000022277";
        String documentType = "ORDER";
        String documentVersion = "ECODRU";
        String documentStandard = "XML";
        String documentTest = "P";
        String dateFrom = "2016-11-29 14:36:09";
        String dateTo = "2016-11-29 14:50:00";

        SoapService soapService = new SoapServiceImpl();
        DocumentStatusResponse responseListPB = soapService.sendListPBRequest(name, password, partnerIln,
                documentType, documentVersion, documentStandard, documentTest, dateFrom, dateTo, timeout);
    }

    private static void makeListMBRequest() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String timeout = "1000";
        String partnerIln = "2000000022277";
        String documentType = "ORDER";
        String documentVersion = "ECODRU";
        String documentStandard = "XML";
        String documentTest = "P";
        String documentStatus = "R";

        SoapService soapService = new SoapServiceImpl();
        MailboxResponse mailboxResponse = soapService.sendListMBRequest(name, password, partnerIln,
                documentType, documentVersion, documentStandard, documentTest, documentStatus, timeout);
    }

    private static void makeReceiveRequestForDocumentOrder() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String timeout = "1000";
        String partnerIln = "2000000022277";
        String documentType = "ORDER";
        String documentStandard = "XML";
        String trackingId = "{a4242cae-7378-7878-7878-787878787878}";
        String changeDocumentStatus = "F";

        SoapService soapService = new SoapServiceImpl();
        DocumentOrder documentOrder = soapService.sendReceiveRequestForDocumentOrder(name, password, partnerIln,
                documentType, trackingId, documentStandard, changeDocumentStatus, timeout);
    }

    private static void makeReceiveRequestForDocumentRecAdv() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String timeout = "1000";
        String partnerIln = "2000000022277";
        String documentType = "RECADV";
        String documentStandard = "XML";
        String trackingId = "{4bf8e3ab-7378-7878-7878-787878787878}";
        String changeDocumentStatus = "F";

        SoapService soapService = new SoapServiceImpl();
        DocumentRecAdv documentRecAdv = soapService.sendReceiveRequestForDocumentRecAdv(name, password, partnerIln,
                documentType, trackingId, documentStandard, changeDocumentStatus, timeout);
    }

    private static void makeSendRequest() throws Exception {
        String name = "2000000022284WU";
        String password = "PA3dwx";
        String partnerIln = "2000000022277";
        String documentType = "DESADV";
        String documentVersion = "ECODRU20";
        String documentStandard = "XML";
        String documentTest = "P";
        String controlNumber = "678";
        String documentContent = "<content>Hello!</content>";
        String timeout = "1000";

        SoapService soapService = new SoapServiceImpl();
        String response = soapService.sendSend(name, password, partnerIln,
                documentType, documentVersion, documentStandard,
                documentTest, controlNumber, documentContent, timeout);
    }

}
