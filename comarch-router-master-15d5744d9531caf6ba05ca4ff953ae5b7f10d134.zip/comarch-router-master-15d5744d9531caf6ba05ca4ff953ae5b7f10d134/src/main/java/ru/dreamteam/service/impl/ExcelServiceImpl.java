package ru.dreamteam.service.impl;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.Route;
import ru.dreamteam.service.ExcelService;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ExcelServiceImpl implements ExcelService {

    private static int ROUTE_SENDER_CELL_ID = 0;
    private static int ROUTE_DELIVERY_POINT_CELL_ID = 1;
    private static int ROUTE_ROUTING_SENDER_CELL_ID = 2;
    private static int ROUTE_RECEIVER_CELL_ID = 3;

    @Override
    public String parseXLSX(InputStream xlsxFileInputStream) throws IOException {

        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = new XSSFWorkbook(xlsxFileInputStream);

        // Return first sheet from the XLSX workbook
        XSSFSheet mySheet = myWorkBook.getSheetAt(0);

        // Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = mySheet.iterator();

        // Traversing over each row of XLSX file
        String result = "";
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            // For each row, iterate through each columns
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_STRING:
                        result += cell.getStringCellValue() + "\t";
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        result += cell.getNumericCellValue() + "\t";
                        break;
                    case Cell.CELL_TYPE_BOOLEAN:
                        result += cell.getBooleanCellValue() + "\t";
                        break;
                    default:
                }
            }
            result += "\n";
        }
        return result;
    }

    @Override
    public List<Route> parseRoutesXLSX(InputStream excelFileInputStream) throws IOException {

        // Finds the workbook instance for XLSX file
        XSSFWorkbook myWorkBook = new XSSFWorkbook(excelFileInputStream);

        // Return first sheet from the XLSX workbook
        XSSFSheet mySheet = myWorkBook.getSheetAt(0);

        // Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = mySheet.iterator();

        // Skip first row with titles
        rowIterator.next();

        // Traversing over each row of XLSX file
        List<Route> routes = new ArrayList<>();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            // For each row, iterate through each columns
            Route route = new Route();
            route.setSender(String.format("%.0f", row.getCell(ROUTE_SENDER_CELL_ID).getNumericCellValue()));
            route.setDeliveryPoint(String.format("%.0f", row.getCell(ROUTE_DELIVERY_POINT_CELL_ID).getNumericCellValue()));
            route.setRoutingSender(String.format("%.0f", row.getCell(ROUTE_SENDER_CELL_ID).getNumericCellValue()));
            route.setReceiver(String.format("%.0f", row.getCell(ROUTE_RECEIVER_CELL_ID).getNumericCellValue()));
            routes.add(route);
        }
        return routes;
    }


}
