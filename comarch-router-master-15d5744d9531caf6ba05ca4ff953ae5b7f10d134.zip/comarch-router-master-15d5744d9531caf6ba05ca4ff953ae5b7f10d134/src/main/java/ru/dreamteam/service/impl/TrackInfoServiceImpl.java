package ru.dreamteam.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.TrackInfo;
import ru.dreamteam.repository.TrackInfoRepository;
import ru.dreamteam.service.TrackInfoService;

import java.util.Date;
import java.util.List;

@Service
public class TrackInfoServiceImpl implements TrackInfoService {
    private final int PAGE_SIZE = 10;

    @Autowired
    private TrackInfoRepository trackInfoRepository;

    public TrackInfo findOne(String trackInfoId) {
        return trackInfoRepository.findOne(trackInfoId);
    }

    public List<TrackInfo> findAll() {
        return trackInfoRepository.findAll();
    }

    @Override
    public TrackInfo create(TrackInfo.DocType docType, Date date, String number, String glnReceiver, String trackingId) {
        return trackInfoRepository.save(new TrackInfo(docType, date, number, glnReceiver, trackingId));
    }

    public TrackInfo create(TrackInfo.DocType docType, Date date, String number, String glnReceiver, String trackingId,
                            String originalXml, String replacedXml, boolean successfull) {
        return trackInfoRepository.save(new TrackInfo(docType, date, number, glnReceiver, trackingId, originalXml, replacedXml, successfull));
    }

    @Override
    public TrackInfo create(TrackInfo trackInfo) {
        return this.create(trackInfo.getDocType(), trackInfo.getDate(), trackInfo.getDocNumber(),
                trackInfo.getGlnReceiver(), trackInfo.getTrackingId(), trackInfo.getOriginalXml(),
                trackInfo.getReplacedXml(), trackInfo.isSuccessful());
    }

    public TrackInfo delete(String trackInfoId) {
        TrackInfo trackInfo = findOne(trackInfoId);
        trackInfoRepository.delete(trackInfoId);
        return trackInfo;
    }

    public TrackInfo update(TrackInfo trackInfo) {
        return trackInfoRepository.save(trackInfo);
    }

    @Override
    public boolean exists(String id) {
        return trackInfoRepository.exists(id);
    }

    @Override
    public boolean existsByTrackingId(String trackingId) {
        List<TrackInfo> trackInfoList = trackInfoRepository.findByTrackingId(trackingId);
        return trackInfoList != null && trackInfoList.size() != 0;
    }

    @Override
    public List<TrackInfo> getByPage(int pageNumber) {
        return trackInfoRepository.findAll(new PageRequest(pageNumber, PAGE_SIZE)).getContent();
    }

    @Override
    public Long getAllCount() {
        return trackInfoRepository.count();
    }

    @Override
    public List<TrackInfo> findByPageAndFilter(int pageNumber, String docType, String number, String gln, String trackingId, Boolean status,Date startDate,Date endDate) {
        return trackInfoRepository.findByPageAndFilter(new PageRequest(pageNumber, PAGE_SIZE), docType, number, gln, trackingId, status,startDate,endDate);
    }

    @Override
    public Long countByPageAndFilter(String docType, String number, String gln, String trackingId, Boolean status, Date startDate, Date endDate) {
        return trackInfoRepository.countByPageAndFilter(docType, number, gln, trackingId, status,startDate,endDate);
    }


    @Override
    public TrackInfo findByTrackingIdAndDocType(String trackingId, TrackInfo.DocType docType) {
        return trackInfoRepository.findByTrackingIdAndType(trackingId, docType);
    }

}
