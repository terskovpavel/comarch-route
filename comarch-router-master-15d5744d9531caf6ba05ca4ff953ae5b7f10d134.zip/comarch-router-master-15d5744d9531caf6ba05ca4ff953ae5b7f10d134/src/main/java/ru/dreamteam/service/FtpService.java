package ru.dreamteam.service;

import ru.dreamteam.model.FTP;
import ru.dreamteam.model.ftp.FtpDesAdvContainer;
import ru.dreamteam.model.ftp.FtpOrdResContainer;
import ru.dreamteam.model.ftp.FtpRecAdvContainer;
import ru.dreamteam.model.ftp.xml.DesAdv;
import ru.dreamteam.model.ftp.FTPInfo;
import ru.dreamteam.model.ftp.xml.OrdRes;
import ru.dreamteam.model.ftp.xml.RecAdv;

import java.io.FileNotFoundException;
import java.util.List;

public interface FtpService {

    /**
     * Скачивания файла с FTP сервера.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteFile
     * @param localFile
     */
    void downloadFile(String hostname, int port, String username, String password,
                      String remoteFile, String localFile);

    /**
     * Загрузки файла на FTP сервер.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param localFile
     * @param remoteFile
     */
    void uploadFile(String hostname, int port, String username, String password,
                    String localFile, String remoteFile);

    /**
     * Сохрание строки в виде файла на FTP сервере.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param content
     * @param tmpLocalFile
     * @param remoteFile
     * @throws FileNotFoundException
     */
    void uploadString(String hostname, int port, String username, String password,
                      String content, String tmpLocalFile, String remoteFile) throws FileNotFoundException;

    /**
     * Загрузка всех файлов из указанной директории на FTP сервере в виде списка строк.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    List<String> downloadFilesAsStrings(String hostname, int port, String username, String password,
                                        String remoteDir);

    /**
     * Удаление всех файлов в указанной директории на FTP сервере.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     */
    void removeFilesInDir(String hostname, int port, String username, String password,
                          String remoteDir);

    /**
     * Удаление указанного файла на FTP сервере.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @param fileName
     */
    void removeFileInDir(String hostname, int port, String username, String password,
                         String remoteDir, String fileName);

    /**
     * Загрузка файлов из указанной директории на FTP сервере в виде списка объектов типа FTPInfo.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    List<FTPInfo> downloadFtpInfos(String hostname, int port, String username, String password,
                                   String remoteDir);

    /**
     * Загрузка файлов из указанной директории на FTP сервере в виде списка объектов типа RecAdv.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    List<RecAdv> downloadRecAdvs(String hostname, int port, String username, String password,
                                 String remoteDir);

    /**
     * Загрузка файлов из указанной директории на FTP сервере в виде списка объектов типа OrdRes.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    List<OrdRes> downloadOrdReses(String hostname, int port, String username, String password,
                                  String remoteDir);

    List<FtpOrdResContainer> downloadFtpOrdRes(String hostname, int port, String username, String password,
                                               String remoteDir);

    List<FtpDesAdvContainer> downloadFtpDesAdv(String hostname, int port, String username, String password,
                                               String remoteDir);

    List<FtpRecAdvContainer> downloadFtpRecAdv(String hostname, int port, String username, String password,
                                               String remoteDir);

    /**
     * Загрузка файлов из указанной директории на FTP сервере в виде списка объектов типа DesAdv.
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    List<DesAdv> downloadDesAdvs(String hostname, int port, String username, String password,
                                 String remoteDir);

    /**
     * Получение из входящей строки в виде "desadv_EDIEx_0289749.xml" значение ID документа
     * (в данном случае ID равен 0289749)
     *
     * @param fileName
     * @return
     */
    String getDocumentIdFromFilename(String fileName);

    FTP findOne(String ftpId);

    List<FTP> findAll();

    FTP create(String gln, String ip, String department, String login, String password);

    FTP findBySupplier(String supplierId);

    FTP create(FTP ftp);

    FTP delete(String ftpId);

    FTP update(FTP ftp);

    List<FTP> getByPage(int pageNumber);

}
