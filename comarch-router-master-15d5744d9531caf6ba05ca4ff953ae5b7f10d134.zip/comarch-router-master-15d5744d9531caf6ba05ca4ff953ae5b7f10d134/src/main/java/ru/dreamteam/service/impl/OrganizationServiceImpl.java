package ru.dreamteam.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.Organization;
import ru.dreamteam.repository.OrganizationRepository;
import ru.dreamteam.service.OrganizationService;

import java.util.List;

@Service
public class OrganizationServiceImpl implements OrganizationService {

    private final int PAGE_SIZE = 10;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Override
    public Organization findOne(String organizationId) {
        return organizationRepository.findOne(organizationId);
    }

    @Override
    public List<Organization> findAll() {
        return organizationRepository.findAll();
    }

    @Override
    public List<Organization> findByOrgType(String orgType) {
        return organizationRepository.findByOrgType(orgType);
    }

    @Override
    public List<Organization> findAllWithHeadIdNotNullAndOrgTypeSupplier() {
        return organizationRepository.findAllWithHeadIdNotNullAndOrgTypeSupplier();
    }

    @Override
    public Organization create(String name, Organization.ORG_TYPE orgType, String headId, String password, String gln, String login) {
        return organizationRepository.save(new Organization(name, orgType, headId, password, gln, login));
    }

    @Override
    public Organization delete(String organizationId) {
        Organization organization = findOne(organizationId);
        organizationRepository.delete(organizationId);
        return organization;
    }

    @Override
    public Organization update(Organization organization) {
        return organizationRepository.save(organization);
    }

    @Override
    public List<Organization> organizationsByHeadId(String headId) {
        return organizationRepository.organizationsByHeadId(headId);
    }

    @Override
    public List<Organization> getByPage(int pageNumber) {
        return organizationRepository.findAll(new PageRequest(pageNumber, PAGE_SIZE)).getContent();
    }

    @Override
    public Organization findByGln(String gln) {
        return organizationRepository.findByGln(gln);
    }

    @Override
    public List<Organization> getByOrgTypeAndPage(String orgType, int pageNumber) {
        return organizationRepository.findByOrgTypeAndPageNumber(orgType, new PageRequest(pageNumber, PAGE_SIZE));
    }
}
