package ru.dreamteam.service;

import ru.dreamteam.model.soap.receive.DocumentOrder;
import ru.dreamteam.model.soap.DocumentStatusResponse;
import ru.dreamteam.model.soap.MailboxResponse;
import ru.dreamteam.model.soap.RelationResponse;
import ru.dreamteam.model.soap.receive.DocumentRecAdv;

/**
 * Created by kiv1n on 28-Nov-16.
 */
public interface SoapService {

    /**
     * Отправка запроса Relationship с указанными параметрами.
     *
     * @param name
     * @param password
     * @param timeout
     * @return
     * @throws Exception
     */
    RelationResponse sendRelationshipsRequest(String name, String password, String timeout) throws Exception;

    /**
     * Отправка запроса ListPB с указанными параметрами.
     *
     * @param name
     * @param password
     * @param partnerIln
     * @param documentType
     * @param documentVersion
     * @param documentStandard
     * @param documentTest
     * @param dateFrom
     * @param dateTo
     * @param timeout
     * @return
     * @throws Exception
     */
    DocumentStatusResponse sendListPBRequest(String name, String password, String partnerIln,
                                             String documentType, String documentVersion,
                                             String documentStandard, String documentTest,
                                             String dateFrom, String dateTo,
                                             String timeout) throws Exception;

    /**
     * Отправка запроса ListMB с указанными параметрами.
     *
     * @param name
     * @param password
     * @param partnerIln
     * @param documentType
     * @param documentVersion
     * @param documentStandard
     * @param documentTest
     * @param documentStatus
     * @param timeout
     * @return
     * @throws Exception
     */
    MailboxResponse sendListMBRequest(String name, String password, String partnerIln,
                                      String documentType, String documentVersion,
                                      String documentStandard, String documentTest,
                                      String documentStatus, String timeout) throws Exception;

    /**
     * Отправка запроса Receive с указанными параметрами для получение объектов типа DocumentOrder.
     *
     * @param name
     * @param password
     * @param partnerIln
     * @param documentType
     * @param trackingId
     * @param documentStandard
     * @param changeDocumentStatus
     * @param timeout
     * @return
     * @throws Exception
     */
    DocumentOrder sendReceiveRequestForDocumentOrder(String name, String password, String partnerIln,
                                                     String documentType, String trackingId,
                                                     String documentStandard, String changeDocumentStatus,
                                                     String timeout) throws Exception;

    /**
     * Отправка запроса Receive с указанными параметрами для получение объектов типа DocumentRecAdv.
     *
     * @param name
     * @param password
     * @param partnerIln
     * @param documentType
     * @param trackingId
     * @param documentStandard
     * @param changeDocumentStatus
     * @param timeout
     * @return
     * @throws Exception
     */
    DocumentRecAdv sendReceiveRequestForDocumentRecAdv(String name, String password, String partnerIln,
                                                       String documentType, String trackingId,
                                                       String documentStandard, String changeDocumentStatus,
                                                       String timeout) throws Exception;

    /**
     * Отправка запроса Send с указанными параметрами для получение объектов типа DocumentOrder.
     *
     * @param name
     * @param password
     * @param partnerIln
     * @param documentType
     * @param documentVersion
     * @param documentStandard
     * @param documentTest
     * @param controlNumber
     * @param documentContent
     * @param timeout
     * @return
     * @throws Exception
     */
    String sendSend(String name, String password, String partnerIln,
                    String documentType, String documentVersion,
                    String documentStandard, String documentTest,
                    String controlNumber, String documentContent,
                    String timeout) throws Exception;

}
