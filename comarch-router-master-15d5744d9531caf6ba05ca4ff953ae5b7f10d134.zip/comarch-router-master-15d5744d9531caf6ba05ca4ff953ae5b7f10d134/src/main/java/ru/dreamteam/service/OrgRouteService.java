package ru.dreamteam.service;

import ru.dreamteam.model.OrgRoute;

import java.util.Date;
import java.util.List;

public interface OrgRouteService {
    OrgRoute findOne(String orgRouteId);

    List<OrgRoute> findAll();

    List<OrgRoute> findAllByDocType(OrgRoute.DocType docType);

    OrgRoute create(String tsId, String supplierId, Date creationDate, String comment,List<OrgRoute.DocType> docTypes,String userName);

    OrgRoute delete(String orgRouteId);

    OrgRoute update(OrgRoute orgRoute);

    List<OrgRoute> getByPage(int pageNumber);
}
