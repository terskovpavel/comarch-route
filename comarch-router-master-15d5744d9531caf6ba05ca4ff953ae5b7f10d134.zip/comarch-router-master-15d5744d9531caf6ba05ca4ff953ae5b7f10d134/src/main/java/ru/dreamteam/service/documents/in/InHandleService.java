package ru.dreamteam.service.documents.in;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import ru.dreamteam.model.OrgRoute;
import ru.dreamteam.model.Organization;
import ru.dreamteam.model.Route;
import ru.dreamteam.model.soap.MailboxResponse;
import ru.dreamteam.model.soap.RelationResponse;
import ru.dreamteam.service.*;
import ru.dreamteam.utils.DateUtils;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Абстрактный класс который реализует общие методы обработки документов из SOAP
 */
public abstract class InHandleService implements Runnable {

    @Autowired
    protected SoapService soapService;

    @Autowired
    protected TrackInfoService trackInfoService;

    @Autowired
    protected FtpService ftpService;

    @Autowired
    protected OrgRouteService orgRouteService;

    @Autowired
    protected OrganizationService organizationService;

    @Autowired
    protected RouteService routeService;

    protected final static String TIMEOUT = "1000";
    private final static String IN = "IN";
    private final static String[] STATUSES = new String[]{"R", "N"};
    protected final static int PORT = 21;
    private final static String FILE_NAME = "{type}_{date}_{trackingId}.xml";

    protected abstract OrgRoute.DocType getDocType();

    protected abstract String getDocumentType();

    protected abstract String getDocumentTest();

    protected abstract String getDocumentFolder();

    protected abstract void handleReceiveResponse(List<MailboxResponse.DocumentInfo> documentInfos, Organization supplier, RelationResponse.Relation relation,
                                                  List<Route> routes, String nowDate) throws Exception;

    protected abstract Logger getLogger();

    /**
     * Метод который выгружает документы из SOAP в FTP
     */
    public void run() {
        getLogger().info("Start loading ");
        List<OrgRoute> orgRoutes = orgRouteService.findAllByDocType(getDocType());
        String nowDate = DateUtils.getFormattedString(new DateTime());
        for (OrgRoute orgRoute : orgRoutes) {
            //Подмаршруты для данного маршрута
            List<Route> routes = routeService.findByOrgRouteId(orgRoute.getId());
            Organization supplier = organizationService.findOne(orgRoute.getSupplierId());
            Organization buyer = organizationService.findOne(orgRoute.getTsId());
            // Make Relationships Request
            RelationResponse responseRelationships = null;
            try {
                responseRelationships = soapService.sendRelationshipsRequest(supplier.getLogin(), supplier.getPassword(), TIMEOUT);
            } catch (Exception e) {
                getLogger().error(e);
            }
            List<RelationResponse.Relation> relations = responseRelationships.getRelations().stream().filter(relationFilter(buyer.getGln())).collect(Collectors.toList());
            getLogger().info("Получили список relations; Размер " + relations.size());
            for (RelationResponse.Relation relation : relations) {
                MailboxResponse mailboxResponse;
                try {
                    for (String status : STATUSES) {
                        mailboxResponse = soapService.sendListMBRequest(supplier.getLogin(), supplier.getPassword(), relation.getPartnerIln(),
                                relation.getDocumentType(), relation.getDocumentVersion(), relation.getDocumentStandard(), relation.getDocumentTest(), status, TIMEOUT);
                        if (mailboxResponse.getDocumentInfos() == null || mailboxResponse.getDocumentInfos().isEmpty()) {
                            getLogger().info("Документ ListMB пустой");
                            continue;
                        }
                        List<MailboxResponse.DocumentInfo> documentInfos = mailboxResponse.getDocumentInfos().stream().filter(mailBoxFilter()).collect(Collectors.toList());
                        getLogger().info("Получили список ListMB; Размер " + documentInfos.size());
                        handleReceiveResponse(documentInfos, supplier, relation, routes, nowDate);
                    }
                } catch (Exception e) {
                    getLogger().error(e);
                }
            }
        }
    }

    /**
     * Фильтр по direction, documentType, documentTest, partnerIln
     */
    private Predicate<RelationResponse.Relation> relationFilter(String buyer) {
        Predicate<RelationResponse.Relation> predicate = (relation ->
                relation.getDirection().equals(IN) &&
                        relation.getDocumentType().equals(getDocumentType()) &&
                        relation.getDocumentTest().equals(getDocumentTest()) &&
                        relation.getPartnerIln().equals(buyer));
        return predicate;
    }

    /**
     * Фильтр по DocumentType
     *
     * @return
     */
    private Predicate<MailboxResponse.DocumentInfo> mailBoxFilter() {
        Predicate<MailboxResponse.DocumentInfo> predicate = (document ->
                document.getDocumentType().equals(getDocumentType())
        );
        return predicate;
    }

    /**
     * Генирируется имя файла в формате {type}_{date}_{trackingId}.xml
     */
    protected String generateFileName(MailboxResponse.DocumentInfo documentInfo, String nowDate) {
        String fileName = FILE_NAME.replace("{type}", getDocumentType().toLowerCase()).replace("{date}", nowDate).replace("{trackingId}", documentInfo.getTrackingId());
        return fileName;
    }

}
