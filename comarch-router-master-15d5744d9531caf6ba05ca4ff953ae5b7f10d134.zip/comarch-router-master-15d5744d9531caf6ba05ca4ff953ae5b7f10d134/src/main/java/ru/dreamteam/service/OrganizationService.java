package ru.dreamteam.service;

import ru.dreamteam.model.Organization;

import java.util.List;

public interface OrganizationService {

    Organization findOne(String organizationId);

    List<Organization> findAll();

    List<Organization> findByOrgType(String orgName);

    List<Organization> findAllWithHeadIdNotNullAndOrgTypeSupplier();

    Organization create(String name, Organization.ORG_TYPE orgType, String headId, String password, String gln, String login);

    Organization delete(String organizationId);

    Organization update(Organization organization);

    List<Organization> organizationsByHeadId(String headId);

    List<Organization> getByPage(int pageNumber);

    Organization findByGln(String gln);

    List<Organization> getByOrgTypeAndPage(String orgType, int pageNumber);

}
