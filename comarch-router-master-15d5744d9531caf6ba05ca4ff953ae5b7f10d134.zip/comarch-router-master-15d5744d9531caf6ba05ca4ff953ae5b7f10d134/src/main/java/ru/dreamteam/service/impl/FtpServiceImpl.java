package ru.dreamteam.service.impl;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.ftp.FTPInfo;
import ru.dreamteam.model.ftp.FtpDesAdvContainer;
import ru.dreamteam.model.ftp.FtpOrdResContainer;
import ru.dreamteam.model.ftp.FtpRecAdvContainer;
import ru.dreamteam.model.ftp.xml.DesAdv;
import ru.dreamteam.model.ftp.xml.OrdRes;
import ru.dreamteam.model.ftp.xml.RecAdv;
import ru.dreamteam.repository.FTPRepository;
import ru.dreamteam.service.FtpService;

import javax.xml.bind.JAXB;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class FtpServiceImpl implements FtpService {
    private final int PAGE_SIZE = 10;

    @Autowired
    private FTPRepository ftpRepository;
    private final static Logger LOGGER = Logger.getLogger(FtpServiceImpl.class);

    /**
     * Сохранение файла на FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteFile
     * @param localFile
     */
    @Override
    public void downloadFile(String hostname, int port, String username, String password, String remoteFile, String localFile) {
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(new File(localFile)));
            boolean success = ftpClient.retrieveFile(remoteFile, outputStream);
            outputStream.close();

            if (success) {
                System.out.println("File has been downloaded successfully. " + remoteFile);
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Сохранение файла на FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param localFile
     * @param remoteFile
     */
    @Override
    public void uploadFile(String hostname, int port, String username, String password, String localFile, String remoteFile) {
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            InputStream inputStream = new BufferedInputStream(new FileInputStream(new File(localFile)));
            boolean success = ftpClient.appendFile(remoteFile, inputStream);
            inputStream.close();

            if (success) {
                System.out.println("File has been uploaded successfully. " + remoteFile);
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Сохранение файла на FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param content
     * @param tmpLocalFile
     * @param remoteFile
     * @throws FileNotFoundException
     */
    @Override
    public void uploadString(String hostname, int port, String username, String password,
                             String content, String tmpLocalFile, String remoteFile) throws FileNotFoundException {

        // Write content to local tmp file
        try (PrintWriter out = new PrintWriter(tmpLocalFile)) {
            out.println(content);
        }

        // Upload file
        uploadFile(hostname, port, username, password, tmpLocalFile, remoteFile);

        // Remove local tmp file
        File file = new File(tmpLocalFile);
        file.delete();
    }

    /**
     * Выкачка всех документов в виде строки из FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    @Override
    public List<String> downloadFilesAsStrings(String hostname, int port, String username, String password, String remoteDir) {
        List<String> filesAsStrings = new ArrayList<>();
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            FTPFile[] ftpFiles = ftpClient.listFiles(remoteDir);
            for (FTPFile ftpFile : ftpFiles) {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                ftpClient.retrieveFile(remoteDir + "/" + ftpFile.getName(), outputStream);
                filesAsStrings.add(new String(outputStream.toByteArray()));
            }

        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        return filesAsStrings;
    }

    /**
     * Удаление всех файлов их директории
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     */
    @Override
    public void removeFilesInDir(String hostname, int port, String username, String password, String remoteDir) {
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            FTPFile[] ftpFiles = ftpClient.listFiles(remoteDir);
            for (FTPFile ftpFile : ftpFiles) {
                ftpClient.deleteFile(remoteDir + "/" + ftpFile.getName());
            }

        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Удаление файла из директории
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @param fileName
     */
    @Override
    public void removeFileInDir(String hostname, int port, String username, String password, String remoteDir, String fileName) {
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            // Delete file
            ftpClient.deleteFile(remoteDir + "/" + fileName);

        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Выкачка файлов из FTP из определенной папки
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    @Override
    public List<FTPInfo> downloadFtpInfos(String hostname, int port, String username, String password, String remoteDir) {
        List<String> filesAsStrings = new ArrayList<>();
        List<FTPInfo> ftpInfos = new ArrayList<>();
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(hostname, port);
            ftpClient.login(username, password);
            ftpClient.enterLocalPassiveMode();
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

            FTPFile[] ftpFiles = ftpClient.listFiles(remoteDir);
            for (FTPFile ftpFile : ftpFiles) {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                ftpClient.retrieveFile(remoteDir + "/" + ftpFile.getName(), outputStream);
                ftpInfos.add(new FTPInfo(ftpFile.getName(), new String(outputStream.toByteArray())));
            }

        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        return ftpInfos;
    }

    /**
     * Выкачка документов типа RECADV из FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    @Override
    public List<RecAdv> downloadRecAdvs(String hostname, int port, String username, String password, String remoteDir) {

        List<RecAdv> recAdvList = new ArrayList<>();

        // Load files from FTP
        List<String> filesAsStrings = downloadFilesAsStrings(hostname, port, username, password, remoteDir);

        // Map files to objects
        for (String fileAsString : filesAsStrings) {
            RecAdv recAdv = JAXB.unmarshal(new StringReader(fileAsString), RecAdv.class);
            recAdvList.add(recAdv);
        }

        return recAdvList;
    }

    /**
     * Выкачка документов типа ORDERS из FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    @Override
    public List<OrdRes> downloadOrdReses(String hostname, int port, String username, String password, String remoteDir) {

        List<OrdRes> ordResList = new ArrayList<>();

        // Load files from FTP
        List<String> filesAsStrings = downloadFilesAsStrings(hostname, port, username, password, remoteDir);

        // Map files to objects
        for (String fileAsString : filesAsStrings) {
            OrdRes ordRes = JAXB.unmarshal(new StringReader(fileAsString), OrdRes.class);
            ordResList.add(ordRes);
        }
        return ordResList;
    }

    @Override
    public List<FtpOrdResContainer> downloadFtpOrdRes(String hostname, int port, String username, String password, String remoteDir) {
        List<FTPInfo> ftpInfos = downloadFtpInfos(hostname, port, username, password, remoteDir);
        List<FtpOrdResContainer> resContainers = new ArrayList<>();
        for (FTPInfo ftpInfo : ftpInfos) {
            OrdRes ordRes = JAXB.unmarshal(new StringReader(ftpInfo.getFileContent()), OrdRes.class);
            FtpOrdResContainer ftpOrdResContainer = new FtpOrdResContainer(ordRes, ftpInfo);
            resContainers.add(ftpOrdResContainer);
        }
        return resContainers;
    }

    @Override
    public List<FtpDesAdvContainer> downloadFtpDesAdv(String hostname, int port, String username, String password, String remoteDir) {
        List<FTPInfo> ftpInfos = downloadFtpInfos(hostname, port, username, password, remoteDir);
        List<FtpDesAdvContainer> desAdvContainers = new ArrayList<>();
        for (FTPInfo ftpInfo : ftpInfos) {
            try {
                DesAdv desAdv = JAXB.unmarshal(new StringReader(ftpInfo.getFileContent()), DesAdv.class);
                FtpDesAdvContainer ftpDesAdvContainer = new FtpDesAdvContainer(desAdv, ftpInfo);
                desAdvContainers.add(ftpDesAdvContainer);
            } catch (Exception e) {
                LOGGER.error(e);
            }
        }
        return desAdvContainers;
    }

    @Override
    public List<FtpRecAdvContainer> downloadFtpRecAdv(String hostname, int port, String username, String password, String remoteDir) {
        List<FTPInfo> ftpInfos = downloadFtpInfos(hostname, port, username, password, remoteDir);
        List<FtpRecAdvContainer> recAdvContainers = new ArrayList<>();
        for (FTPInfo ftpInfo : ftpInfos) {
            RecAdv recAdv = JAXB.unmarshal(new StringReader(ftpInfo.getFileContent()), RecAdv.class);
            FtpRecAdvContainer ftpRecAdvContainer = new FtpRecAdvContainer(recAdv, ftpInfo);
            recAdvContainers.add(ftpRecAdvContainer);
        }
        return recAdvContainers;
    }

    /**
     * Выкачка документов типа DESADV из FTP
     *
     * @param hostname
     * @param port
     * @param username
     * @param password
     * @param remoteDir
     * @return
     */
    @Override
    public List<DesAdv> downloadDesAdvs(String hostname, int port, String username, String password, String remoteDir) {

        List<DesAdv> desAdvList = new ArrayList<>();

        // Load files from FTP
        List<String> filesAsStrings = downloadFilesAsStrings(hostname, port, username, password, remoteDir);

        // Map files to objects
        for (String fileAsString : filesAsStrings) {
            DesAdv desAdv = JAXB.unmarshal(new StringReader(fileAsString), DesAdv.class);
            desAdvList.add(desAdv);
        }

        return desAdvList;
    }

    @Override
    public String getDocumentIdFromFilename(String fileName) {
        String name = "";
        try {
            String[] strings = fileName.split("[_.]+");
            name = strings[strings.length - 2];
        } catch (Exception e) {
            LOGGER.error(e);
        }
        return name;
    }

    @Override
    public ru.dreamteam.model.FTP findOne(String ftpId) {
        return ftpRepository.findOne(ftpId);
    }

    @Override
    public List<ru.dreamteam.model.FTP> findAll() {
        return ftpRepository.findAll();
    }

    @Override
    public ru.dreamteam.model.FTP create(String ip, String department, String login, String password, String supplierId) {
        return ftpRepository.save(new ru.dreamteam.model.FTP(ip, department, login, password, supplierId));
    }

    @Override
    public ru.dreamteam.model.FTP findBySupplier(String supplierId) {
        return ftpRepository.findBySupplier(supplierId);
    }

    @Override
    public ru.dreamteam.model.FTP create(ru.dreamteam.model.FTP ftp) {
        return this.create(ftp.getIp(), ftp.getDepartment(), ftp.getLogin(), ftp.getPassword(), ftp.getSupplierId());
    }

    @Override
    public ru.dreamteam.model.FTP delete(String ftpId) {
        ru.dreamteam.model.FTP ftp = ftpRepository.findOne(ftpId);
        ftpRepository.delete(ftpId);
        return ftp;
    }

    @Override
    public ru.dreamteam.model.FTP update(ru.dreamteam.model.FTP ftp) {
        return ftpRepository.save(ftp);
    }

    @Override
    public List<ru.dreamteam.model.FTP> getByPage(int pageNumber) {
        return ftpRepository.findAll(new PageRequest(pageNumber, PAGE_SIZE)).getContent();
    }
}
