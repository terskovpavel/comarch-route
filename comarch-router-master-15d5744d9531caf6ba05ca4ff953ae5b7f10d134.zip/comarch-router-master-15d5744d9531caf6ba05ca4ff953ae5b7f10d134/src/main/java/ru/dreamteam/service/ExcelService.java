package ru.dreamteam.service;

import ru.dreamteam.model.Route;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Created by kiv1n on 05-Dec-16.
 */
public interface ExcelService {

    /**
     * Считывание указанного файла (потока) формата XLSX и преобразование
     * его в строку.
     *
     * @param excelFileInputStream
     * @return
     * @throws IOException
     */
    String parseXLSX(InputStream excelFileInputStream) throws IOException;

    /**
     * Считывание указанного файла (потока) формата XLSX со специальной структурой
     * (подробнее ниже) и преобразование его в список объектов типа Route.
     *
     * Файл должен удовлетворять следующим правилам:
     * - первая строки содержат это заголовки: sender, deliveryPoint, routingSender, receiver;
     * - последующие строки содержат значения.
     *
     * @param excelFileInputStream
     * @return
     * @throws IOException
     */
    List<Route> parseRoutesXLSX(InputStream excelFileInputStream) throws IOException;

}
