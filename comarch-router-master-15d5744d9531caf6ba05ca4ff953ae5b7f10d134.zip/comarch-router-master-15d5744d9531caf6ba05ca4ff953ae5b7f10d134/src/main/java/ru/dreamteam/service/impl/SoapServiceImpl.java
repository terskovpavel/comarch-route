package ru.dreamteam.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import ru.dreamteam.model.soap.DocumentStatusResponse;
import ru.dreamteam.model.soap.MailboxResponse;
import ru.dreamteam.model.soap.RelationResponse;
import ru.dreamteam.model.soap.receive.DocumentOrder;
import ru.dreamteam.model.soap.receive.DocumentRecAdv;
import ru.dreamteam.service.SoapService;

import javax.xml.bind.JAXB;
import javax.xml.soap.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

@Service
public class SoapServiceImpl implements SoapService {

    private static final String URL = "https://www.ecod.pl/webserv2/EDIservice.asmx";
    private static final String URI = "http://www.comarch.com/";
    private static final String ACTION_RELATIONSHIPS = "Relationships";
    private static final String ACTION_LISTPB = "ListPB";
    private static final String ACTION_LISTMB = "ListMB";
    private static final String ACTION_RECEIVE = "Receive";
    private static final String ACTION_SEND = "Send";
    private static Logger logger = LoggerFactory.getLogger(SoapServiceImpl.class);

    @Override
    public RelationResponse sendRelationshipsRequest(String name, String password, String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_RELATIONSHIPS, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get CNT from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return object parsed from XML
        return JAXB.unmarshal(new StringReader(cnt.getTextContent()), RelationResponse.class);
    }

    @Override
    public DocumentStatusResponse sendListPBRequest(String name, String password, String partnerIln,
                                                    String documentType, String documentVersion,
                                                    String documentStandard, String documentTest,
                                                    String dateFrom, String dateTo, String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("PartnerIln", partnerIln);
        parameterValues.put("DocumentType", documentType);
        parameterValues.put("DocumentVersion", documentVersion);
        parameterValues.put("DocumentStandard", documentStandard);
        parameterValues.put("DocumentTest", documentTest);
        parameterValues.put("DateFrom", dateFrom);
        parameterValues.put("DateTo", dateTo);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_LISTPB, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get content from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return object parsed from XML
        return JAXB.unmarshal(new StringReader(cnt.getTextContent()), DocumentStatusResponse.class);
    }

    @Override
    public MailboxResponse sendListMBRequest(String name, String password, String partnerIln, String documentType,
                                             String documentVersion, String documentStandard, String documentTest,
                                             String documentStatus, String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("PartnerIln", partnerIln);
        parameterValues.put("DocumentType", documentType);
        parameterValues.put("DocumentVersion", documentVersion);
        parameterValues.put("DocumentStandard", documentStandard);
        parameterValues.put("DocumentTest", documentTest);
        parameterValues.put("DocumentStatus", documentStatus);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_LISTMB, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get content from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return object parsed from XML
        return JAXB.unmarshal(new StringReader(cnt.getTextContent()), MailboxResponse.class);
    }

    @Override
    public DocumentOrder sendReceiveRequestForDocumentOrder(String name, String password, String partnerIln,
                                                            String documentType, String trackingId,
                                                            String documentStandard, String changeDocumentStatus,
                                                            String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("PartnerIln", partnerIln);
        parameterValues.put("DocumentType", documentType);
        parameterValues.put("TrackingId", trackingId);
        parameterValues.put("DocumentStandard", documentStandard);
        parameterValues.put("ChangeDocumentStatus", changeDocumentStatus);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_RECEIVE, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get content from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return object parsed from XML
        return JAXB.unmarshal(new StringReader(cnt.getTextContent()), DocumentOrder.class);
    }

    @Override
    public DocumentRecAdv sendReceiveRequestForDocumentRecAdv(String name, String password, String partnerIln,
                                                              String documentType, String trackingId,
                                                              String documentStandard, String changeDocumentStatus,
                                                              String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("PartnerIln", partnerIln);
        parameterValues.put("DocumentType", documentType);
        parameterValues.put("TrackingId", trackingId);
        parameterValues.put("DocumentStandard", documentStandard);
        parameterValues.put("ChangeDocumentStatus", changeDocumentStatus);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_RECEIVE, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get content from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return object parsed from XML
        return JAXB.unmarshal(new StringReader(cnt.getTextContent()), DocumentRecAdv.class);
    }

    @Override
    public String sendSend(String name, String password, String partnerIln, String documentType,
                           String documentVersion, String documentStandard, String documentTest,
                           String controlNumber, String documentContent, String timeout) throws Exception {

        // Init parameters and values
        Map<String, String> parameterValues = new HashMap<>();
        parameterValues.put("Name", name);
        parameterValues.put("Password", password);
        parameterValues.put("PartnerIln", partnerIln);
        parameterValues.put("DocumentType", documentType);
        parameterValues.put("DocumentVersion", documentVersion);
        parameterValues.put("DocumentStandard", documentStandard);
        parameterValues.put("DocumentTest", documentTest);
        parameterValues.put("ControlNumber", controlNumber);
        parameterValues.put("DocumentContent", documentContent);
        parameterValues.put("Timeout", timeout);

        // Send SOAP request
        SOAPMessage response = sendSoapRequest(ACTION_SEND, parameterValues);

        // Get SOAP Body
        Document xml = response.getSOAPBody().extractContentAsDocument();

        // Get content from XML
        Node cnt = xml.getElementsByTagName("Cnt").item(0);

        // Return response
        return cnt.getTextContent();
    }

    /**
     * Метод для отправки SOAP запроса.
     *
     * @param action
     * @param parameterValues
     * @return
     * @throws SOAPException
     * @throws IOException
     */
    private SOAPMessage sendSoapRequest(String action, Map<String, String> parameterValues) throws SOAPException, IOException {

        // Create request
        SOAPMessage request = createRequest(action, parameterValues);

        // Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        // Send SOAP Request to SOAP Server
        SOAPMessage soapResponse = soapConnection.call(request, URL);

        return soapResponse;
    }

    /**
     * Метод для создания сообщения, которое необходимо для отправления запроса.
     *
     * @param action
     * @param parameterValues
     * @return
     * @throws SOAPException
     * @throws IOException
     */
    private SOAPMessage createRequest(String action, Map<String, String> parameterValues) throws SOAPException, IOException {

        // Create SOAP request
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage request = messageFactory.createMessage();

        // SOAP Envelope
        SOAPPart soapPart = request.getSOAPPart();
        SOAPEnvelope envelope = soapPart.getEnvelope();

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement parameterValuesSoapElement = soapBody.addChildElement(action, null, URI);

        for (String parameter : parameterValues.keySet()) {
            SOAPElement soapElement = parameterValuesSoapElement.addChildElement(parameter);
            soapElement.addTextNode(parameterValues.get(parameter));
        }

        // SOAP Headers
        MimeHeaders headers = request.getMimeHeaders();
        headers.addHeader("SOAPAction", URI + action);

        // Save changes
        request.saveChanges();

        // Log the request message
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        request.writeTo(out);
        logger.debug("Request SOAP Message:" + new String(out.toByteArray()));

        // Return
        return request;
    }

}
