package ru.dreamteam.service;


import ru.dreamteam.model.Route;

import java.util.List;

public interface RouteService {
    Route findOne(String routeId);

    List<Route> findAll();

    Route create(String sender, String deliveryPoint, String receiver, String orgRouteId, String routingSender);

    Route create(Route route);

    Route delete(String routeId);

    Route update(Route route);

    List<Route> findByOrgRouteId(String orgRouteId);

    List<Route> findByOrgRouteIdPageble(String orgRouteId, int page);

    List<Route> getByPage(int pageNumber);

    Route findByReceiverAndRoutingSender(String sellerIln, String buyerIln);
}
