package ru.dreamteam.service;

import ru.dreamteam.model.User;

import java.util.List;

/**
 * Created by kiv1n on 04-Dec-16.
 */
public interface UserService {

    User save(User user);

    User findByUsername(String username);

    List<User> findAll();

    User delete(String userId);

    User update(User user);

    User findOne(String id);

}
