package ru.dreamteam.service.documents.in;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.*;
import ru.dreamteam.model.soap.MailboxResponse;
import ru.dreamteam.model.soap.RelationResponse;
import ru.dreamteam.model.soap.receive.DocumentRecAdv;

import javax.xml.bind.JAXB;
import java.io.FileNotFoundException;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;

@Service
public class RecadvHandleService extends InHandleService {

    private final static String DOCUMENT_TYPE = "RECADV";
    private final static String DOCUMENT_TEST = "P";
    private final static String FOLDER = "/IN/RECADV/";
    private final static OrgRoute.DocType DOC_TYPE = OrgRoute.DocType.RECADV_IN;
    private final static Logger LOGGER = Logger.getLogger(RecadvHandleService.class);

    @Override
    protected OrgRoute.DocType getDocType() {
        return DOC_TYPE;
    }

    @Override
    protected String getDocumentType() {
        return DOCUMENT_TYPE;
    }

    @Override
    protected String getDocumentTest() {
        return DOCUMENT_TEST;
    }

    @Override
    protected String getDocumentFolder() {
        return FOLDER;
    }


    /**
     * Получение и обработка метода receive
     *
     * @param documentInfos - результат вызова ListMB
     * @param supplier      - поставщик
     * @param relation
     * @param routes        - подмаршруты для проверки на сопастовление
     * @param nowDate       - дата для сохранения на FTP
     * @throws Exception
     */
    @Override
    protected void handleReceiveResponse(List<MailboxResponse.DocumentInfo> documentInfos, Organization supplier, RelationResponse.Relation relation, List<Route> routes, String nowDate) throws Exception {
        for (MailboxResponse.DocumentInfo documentInfo : documentInfos) {
            //Получение финального документа
            DocumentRecAdv responseReceive = soapService.sendReceiveRequestForDocumentRecAdv(supplier.getLogin(), supplier.getPassword(), documentInfo.getPartnerI1n(),
                    relation.getDocumentType(), documentInfo.getTrackingId(), relation.getDocumentStandard(), documentInfo.getDocumentStatus(), TIMEOUT);
            if (responseReceive.getReceivingAdviceParties() == null) {
                LOGGER.info("Документ receiver пустой");
                continue;
            }
            LOGGER.info("Документ receive успешно получен");
            //Обрабатываем полученный документ
            handleByRoutes(responseReceive, documentInfo, routes, nowDate, supplier);
        }
    }

    @Override
    protected Logger getLogger() {
        return LOGGER;
    }


    /**
     * Сохранение документа в FTP и в БД
     *
     * @param responseReceive
     * @param documentInfo
     * @param route
     * @param nowDate
     * @param supplier
     * @throws FileNotFoundException
     */
    private void saveAndUpload(DocumentRecAdv responseReceive, MailboxResponse.DocumentInfo documentInfo, Route route, String nowDate, Organization supplier) throws FileNotFoundException {
        //оригинальный документ
        String originalXml = marshall(responseReceive);
        responseReceive.getReceivingAdviceParties().getSeller().setILN(route.getReceiver());
        //документ с подстановкой
        String replacedXml = marshall(responseReceive);
        String fileName = generateFileName(documentInfo, nowDate);
        //Сохраняем на FTP
        Organization supplierOrg = organizationService.findByGln(route.getReceiver());
        if (supplierOrg == null) {
            LOGGER.error("Поставщик для " + route + "; Не найден в бд");
            return;
        }
        FTP ftp = ftpService.findBySupplier(supplierOrg.getId());
        if (ftp == null) {
            LOGGER.error("FTP для " + supplierOrg + "; Не найден в бд");
            return;
        }
        ftpService.uploadString(ftp.getIp(), PORT, ftp.getLogin(), ftp.getPassword(), replacedXml, fileName, getDocumentFolder() + fileName);
        //Сохраняем в базу
        TrackInfo trackInfo = new TrackInfo(TrackInfo.DocType.RECADV_IN,
                new Date(), "", supplier.getGln()
                , documentInfo.getTrackingId(),
                originalXml, replacedXml,true);
        trackInfoService.create(trackInfo);
        getLogger().info("Сохраненный документ " + trackInfo);
    }

    /**
     * Проверка документа на сопоставление Подмаршрутам
     *
     * @param responseReceive -
     * @param documentInfo    -
     * @param routes          - Подмаршуты по которым осуществялется проверка и подмена GLN
     * @throws FileNotFoundException
     */
    private void handleByRoutes(DocumentRecAdv responseReceive, MailboxResponse.DocumentInfo documentInfo, List<Route> routes, String nowDate, Organization supplier) throws FileNotFoundException {
        for (Route route : routes) {
            if (checkIfPairsMatch(responseReceive, route)) {
                getLogger().info("Подмаршрут, подходящий по условию " + route);
                //Если документ находится в базе, то не обрабатываем его
                boolean exists = trackInfoService.existsByTrackingId(documentInfo.getTrackingId());
                if (!exists) {
                    saveAndUpload(responseReceive, documentInfo, route, nowDate, supplier);
                }
                //Выходим из цикла, как только нашли подходящий подмаршрут
                break;
            }
        }
    }

    /**
     * Конвертирует объект в XML
     */
    protected String marshall(DocumentRecAdv documentOrder) {
        StringWriter writer = new StringWriter();
        JAXB.marshal(documentOrder, writer);
        return writer.toString();
    }


    /**
     * Проверка на сопоставление подмаршрута и определенного документа
     *
     * @param responseReceive
     * @param route
     * @return
     */
    protected boolean checkIfPairsMatch(DocumentRecAdv responseReceive, Route route) {
        DocumentRecAdv.ReceivingAdviceParties.Buyer buyer = responseReceive.getReceivingAdviceParties().getBuyer();
        DocumentRecAdv.ReceivingAdviceParties.DeliveryPoint deliveryPoint = responseReceive.getReceivingAdviceParties().getDeliveryPoint();
        if (buyer == null || deliveryPoint == null) {
            LOGGER.warn("Document have buyer or delivery point null " + responseReceive);
            return false;
        }
        if (buyer.getILN().equals(route.getSender())
                && deliveryPoint.getILN().equals(route.getDeliveryPoint())) {
            return true;
        }
        return false;
    }
}
