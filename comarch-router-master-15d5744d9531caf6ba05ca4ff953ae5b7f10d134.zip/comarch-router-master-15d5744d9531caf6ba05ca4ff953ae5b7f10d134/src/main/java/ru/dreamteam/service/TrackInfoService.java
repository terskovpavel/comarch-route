package ru.dreamteam.service;

import ru.dreamteam.model.TrackInfo;

import java.util.Date;
import java.util.List;

public interface TrackInfoService {
    TrackInfo findOne(String trackInfoId);

    List<TrackInfo> findAll();

    TrackInfo create(TrackInfo.DocType docType, Date date, String number, String glnReceiver, String trackingId);

    TrackInfo create(TrackInfo.DocType docType, Date date, String number, String glnReceiver, String trackingId,
                     String originalXml, String replacedXml, boolean successful);

    TrackInfo create(TrackInfo trackInfo);

    TrackInfo delete(String trackInfoId);

    TrackInfo update(TrackInfo trackInfo);

    boolean exists(String id);

    boolean existsByTrackingId(String trackingId);

    List<TrackInfo> getByPage(int pageNumber);

    Long getAllCount();

    List<TrackInfo> findByPageAndFilter(int pageNumber, String docType,
                                        String number, String gln,
                                        String trackingId, Boolean status,Date startDate,Date endDate);


    Long countByPageAndFilter(String docType,
                                        String number, String gln,
                                        String trackingId, Boolean status,Date startDate,Date endDate);


    TrackInfo findByTrackingIdAndDocType(String trackingId, TrackInfo.DocType docType);
}
