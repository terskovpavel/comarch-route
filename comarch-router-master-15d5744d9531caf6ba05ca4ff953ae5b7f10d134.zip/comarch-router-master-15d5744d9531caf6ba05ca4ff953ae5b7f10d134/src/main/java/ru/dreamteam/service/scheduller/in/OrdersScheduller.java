package ru.dreamteam.service.scheduller.in;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.dreamteam.service.documents.in.OrdersHandleSerivce;

import javax.annotation.PostConstruct;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Сервис который запускается в определенный промежуток времени для выкачки ORDERS
 */
@Service
public class OrdersScheduller {
    @Autowired
    private OrdersHandleSerivce ordersHandleSerivce;
    private ScheduledExecutorService executorService;
    private ScheduledFuture<?> scheduledFuture;

    private final int DELAY = 0;
    private final int PERIOD = 5;

    @PostConstruct
    public void init() {
        initScheduller(DELAY, PERIOD);
    }


    public void initScheduller(int delay, int period) {
        executorService = Executors.newSingleThreadScheduledExecutor();
        scheduledFuture =
                executorService.scheduleAtFixedRate(ordersHandleSerivce, delay, period, TimeUnit.MINUTES);
    }

    public void reRunScheduller(int delay, int period) {
        scheduledFuture.cancel(true);
        scheduledFuture = executorService.scheduleAtFixedRate(ordersHandleSerivce, delay, period, TimeUnit.MINUTES);
    }
}
