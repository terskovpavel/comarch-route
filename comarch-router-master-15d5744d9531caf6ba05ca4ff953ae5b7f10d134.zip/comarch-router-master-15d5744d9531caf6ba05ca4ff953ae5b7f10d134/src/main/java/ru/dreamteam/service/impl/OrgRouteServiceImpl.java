package ru.dreamteam.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.OrgRoute;
import ru.dreamteam.repository.OrgRouteRepository;
import ru.dreamteam.service.OrgRouteService;

import java.util.Date;
import java.util.List;

@Service
public class OrgRouteServiceImpl implements OrgRouteService {
    private final int PAGE_SIZE = 10;

    @Autowired
    private OrgRouteRepository orgRouteRepository;

    @Override
    public OrgRoute findOne(String orgRouteId) {
        return orgRouteRepository.findOne(orgRouteId);
    }

    @Override
    public List<OrgRoute> findAll() {
        return orgRouteRepository.findAll();
    }

    @Override
    public List<OrgRoute> findAllByDocType(OrgRoute.DocType docType) {
        return orgRouteRepository.findAllByDocTypes(docType);
    }

    @Override
    public OrgRoute create(String tsId, String supplierId, Date creationDate, String comment,List<OrgRoute.DocType> docTypes,String userName) {
        return orgRouteRepository.save(new OrgRoute(tsId, supplierId, creationDate, comment,docTypes,userName));
    }

    @Override
    public OrgRoute delete(String orgRouteId) {
        OrgRoute orgRoute = orgRouteRepository.findOne(orgRouteId);
        orgRouteRepository.delete(orgRouteId);
        return orgRoute;
    }

    @Override
    public OrgRoute update(OrgRoute orgRoute) {
        return orgRouteRepository.save(orgRoute);
    }

    @Override
    public List<OrgRoute> getByPage(int pageNumber) {
        return orgRouteRepository.findAll(new PageRequest(pageNumber, PAGE_SIZE)).getContent();
    }

}
