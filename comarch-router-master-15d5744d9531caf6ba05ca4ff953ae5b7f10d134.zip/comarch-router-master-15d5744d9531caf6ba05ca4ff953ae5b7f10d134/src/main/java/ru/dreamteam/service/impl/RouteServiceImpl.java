package ru.dreamteam.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import ru.dreamteam.model.Route;
import ru.dreamteam.repository.RouteRepository;
import ru.dreamteam.service.RouteService;

import java.util.List;

@Service
public class RouteServiceImpl implements RouteService {
    public final int PAGE_SIZE = 10;

    @Autowired
    private RouteRepository routeRepository;

    @Override
    public Route findOne(String routeId) {
        return routeRepository.findOne(routeId);
    }

    @Override
    public List<Route> findAll() {
        return routeRepository.findAll();
    }

    @Override
    public Route create(String sender, String deliveryPoint, String receiver, String orgRouteId, String routingSender) {
        return routeRepository.save(new Route(sender, deliveryPoint, receiver, orgRouteId, routingSender));
    }

    @Override
    public Route create(Route route) {
        return this.create(route.getSender(), route.getDeliveryPoint(), route.getReceiver(), route.getOrgRouteId(), route.getRoutingSender());
    }

    @Override
    public Route delete(String routeId) {
        Route route = routeRepository.findOne(routeId);
        routeRepository.delete(routeId);

        return route;
    }

    @Override
    public Route update(Route route) {
        return routeRepository.save(route);
    }

    @Override
    public List<Route> findByOrgRouteId(String orgRouteId) {
        return routeRepository.findByOrgRouteId(orgRouteId);
    }

    @Override
    public List<Route> findByOrgRouteIdPageble(String orgRouteId, int page) {
        int skip = page * PAGE_SIZE;
        return routeRepository.findByOrgRouteIdPageble(orgRouteId, skip, PAGE_SIZE);
    }

    @Override
    public List<Route> getByPage(int pageNumber) {
        return routeRepository.findAll(new PageRequest(pageNumber, PAGE_SIZE)).getContent();
    }

    @Override
    public Route findByReceiverAndRoutingSender(String sellerIln, String buyerIln) {
        return routeRepository.findByReceiverAndRoutingSender(sellerIln, buyerIln);
    }

}
