package ru.dreamteam;

public class MainTest {
    public static void main(String[] args) {
        System.out.println(getDocumentIdFromFilename("DESADV_OUT_15.xml"));
    }

    public static String getDocumentIdFromFilename(String fileName) {
        String[] strings = fileName.split("[_.]+");
        return strings[strings.length - 2];
    }
}
