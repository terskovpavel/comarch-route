package ru.dreamteam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.security.crypto.password.PasswordEncoder;
import ru.dreamteam.config.MongoDBConfig;
import ru.dreamteam.config.SecurityConfig;
import ru.dreamteam.config.ServiceConfig;
import ru.dreamteam.model.*;
import ru.dreamteam.service.*;

import java.util.Arrays;
import java.util.Date;

/**
 * Класс для записи в базу тестовых данных
 */
public class DbMain {

    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(
                MongoDBConfig.class, ServiceConfig.class, SecurityConfig.class);
        saveOrgRoute(applicationContext);
    }

    private static void saveTrackInfo(ApplicationContext applicationContext) {
        TrackInfoService trackInfoService = applicationContext.getBean(TrackInfoService.class);
        TrackInfo trackInfo = new TrackInfo();
        trackInfo.setDocNumber("123456");
        trackInfo.setDate(new Date());
        trackInfo.setDocType(TrackInfo.DocType.ORDERS);
        trackInfo.setGlnReceiver("12312312312");
        trackInfoService.create(trackInfo);
    }

    private static void saveFtp(ApplicationContext applicationContext) {
        FtpService ftpService = applicationContext.getBean(FtpService.class);
        FTP ftp = new FTP();
        ftp.setDepartment("department");
        ftp.setSupplierId("gln");
        ftp.setIp("95.85.40.95");
        ftp.setLogin("sandbox");
        ftp.setPassword("ptV1lU3nQlKLFkQOJtyf");
        ftpService.create(ftp);
    }

//    private static void saveOrganization(ApplicationContext applicationContext) {
//        OrganizationService organizationService = applicationContext.getBean(OrganizationService.class);
//        organizationService.create(null, null, null, Organization.ORG_TYPE.TC, null, null, null);
//    }

    private static void saveUser(ApplicationContext applicationContext) {
        UserService userService = applicationContext.getBean(UserService.class);
        PasswordEncoder passwordEncoder = applicationContext.getBean(PasswordEncoder.class);
        User user = new User();
        user.setUsername("user");
        user.setPassword(passwordEncoder.encode("password"));
        userService.save(user);
    }

    private static void saveRoute(ApplicationContext applicationContext) {
        RouteService routeService = applicationContext.getBean(RouteService.class);
        routeService.create(new Route(null, null, "4607029930019", "58501bd584df651404b4fbf2", "9990000001188"));
    }

    private static void saveOrgRoute(ApplicationContext applicationContext) {
        OrgRouteService orgRouteService = applicationContext.getBean(OrgRouteService.class);
        orgRouteService.create("58501cec84df65215c40426f", "58501ccb84df652d403aa015", null, null, Arrays.asList(OrgRoute.DocType.ORDERSP),"username");
    }


}
