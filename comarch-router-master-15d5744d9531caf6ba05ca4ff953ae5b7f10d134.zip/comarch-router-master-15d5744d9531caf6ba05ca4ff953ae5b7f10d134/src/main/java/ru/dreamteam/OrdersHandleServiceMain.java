package ru.dreamteam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import ru.dreamteam.config.MongoDBConfig;
import ru.dreamteam.config.ServiceConfig;

/**
 * Класс для тестов
 */
public class OrdersHandleServiceMain {
    public static void main(String[] args) {

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MongoDBConfig.class, ServiceConfig.class);
        System.out.println(applicationContext);
    }
}
