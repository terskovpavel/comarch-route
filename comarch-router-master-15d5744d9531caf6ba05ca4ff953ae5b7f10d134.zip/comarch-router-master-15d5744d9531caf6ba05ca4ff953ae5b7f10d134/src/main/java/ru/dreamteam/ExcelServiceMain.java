package ru.dreamteam;

import ru.dreamteam.model.Route;
import ru.dreamteam.service.ExcelService;
import ru.dreamteam.service.impl.ExcelServiceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class ExcelServiceMain {

    public static void main(String[] args) throws IOException {

        String excelFilePath = "C:\\Users\\vampi\\Workspace\\xml_web_service\\tmp\\Маршрут.xlsx";
        ExcelService excelService = new ExcelServiceImpl();

        FileInputStream fileInputStream = new FileInputStream(new File(excelFilePath));
        List<Route> routes = excelService.parseRoutesXLSX(fileInputStream);
    }

}
