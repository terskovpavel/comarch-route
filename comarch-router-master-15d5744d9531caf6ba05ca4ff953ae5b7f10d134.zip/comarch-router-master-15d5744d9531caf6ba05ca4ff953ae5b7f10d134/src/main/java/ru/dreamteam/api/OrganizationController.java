package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.model.Organization;
import ru.dreamteam.service.OrganizationService;

import java.util.List;

@RestController
@RequestMapping(value = "/organization")
public class OrganizationController {
    private final static Logger LOGGER = Logger.getLogger(OrganizationController.class);
    @Autowired
    private OrganizationService organizationService;

    /**
     * Возвращает все Organization из базы данных
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getAllOrganizations() {
        LOGGER.debug("Get all organizations");
        List<Organization> organizationList = organizationService.findAll();
        LOGGER.debug("Got all organizations, size of list: " + organizationList.size());
        return organizationList;
    }

    /**
     * Возвращает все Organization типа SUPPLIER из базы данных
     */
    @RequestMapping(value = "/all/supplier", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getSupplierOrganizations() {
        LOGGER.debug("Get all organizations");
        List<Organization> organizationList = organizationService.findByOrgType(Organization.ORG_TYPE.SUPPLIER.name());
        LOGGER.debug("Got all organizations, size of list: " + organizationList.size());
        return organizationList;
    }

    /**
     * Возвращает все Organization типа TC из базы данных
     */
    @RequestMapping(value = "/all/tc", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getTcOrganizations() {
        LOGGER.debug("Get all organizations");
        List<Organization> organizationList = organizationService.findByOrgType(Organization.ORG_TYPE.TC.name());
        LOGGER.debug("Got all organizations, size of list: " + organizationList.size());
        return organizationList;
    }

    /**
     * Возвращает Organization по id из базы данных
     */
    @RequestMapping(value = "/{organizationId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Organization getOrganization(@PathVariable String organizationId) {
        LOGGER.debug("Get organization");
        Organization organization = organizationService.findOne(organizationId);
        LOGGER.debug("Got organization: " + organization);
        return organization;
    }

    /**
     * Созадаёт Organization в базе данных
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void createOrganization(@RequestBody Organization org) {
        LOGGER.debug("Create organization request");
        Organization organization = organizationService.create(org.getName(), org.getOrgType(), org.getHeadId(), org.getPassword(), org.getGln(), org.getLogin());
        LOGGER.info("Created new organization: " + organization);
    }

    // Удаляет Organization из базы данных
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteOrganization(@PathVariable String id) {
        LOGGER.debug("Delete organization request");
        Organization organization = organizationService.delete(id);
        List<Organization> organizations = organizationService.organizationsByHeadId(organization.getId());
        for (Organization org : organizations) {
            org.setHeadId(null);
            organizationService.update(org);
        }
        LOGGER.info("Deleted organization: " + organization);
    }

    /**
     * Обновляет Organization в базе данных
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public Organization updateOrganization(@RequestBody Organization organization) {
        LOGGER.debug("Update organization request");
        Organization updatedOrganization = organizationService.update(organization);
        LOGGER.info("Updated organization: " + updatedOrganization);
        return updatedOrganization;
    }

    /**
     * Получает все Organization по headId
     */
    @RequestMapping(value = "/all/{headId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getOrganizationsByHeadId(@PathVariable String headId) {
        LOGGER.debug("Get all organizations by head id - " + headId);
        List<Organization> organizationList = organizationService.organizationsByHeadId(headId);
        LOGGER.debug("Got all organizations by head id, size of list: " + organizationList.size());
        return organizationList;
    }

    /**
     * Пагинация Organization по типу Supplier
     */
    @RequestMapping(value = "/supplier/page/{pageNumber}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getSupplierOrganizationsByPage(@PathVariable int pageNumber) {
        LOGGER.debug("Get Supplier organizations by page - #" + pageNumber);
        List<Organization> organizationList = organizationService.getByOrgTypeAndPage(Organization.ORG_TYPE.SUPPLIER.name(), pageNumber);
        LOGGER.debug("Got Supplier organizations by page, size of list: " + organizationList.size());
        return organizationList;
    }

    /**
     * Пагинация Organization по типу TC
     */
    @RequestMapping(value = "/tc/page/{pageNumber}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getTCOrganizationsByPage(@PathVariable int pageNumber) {
        LOGGER.debug("Get TC organizations by page - #" + pageNumber);
        List<Organization> organizationList = organizationService.getByOrgTypeAndPage(Organization.ORG_TYPE.TC.name(), pageNumber);
        LOGGER.debug("Got TC organizations by page, size of list: " + organizationList.size());
        return organizationList;
    }


    /**
     * Получает все филлиалы из базы данных
     */
    @RequestMapping(value = "/suppliers/branches", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Organization> getSupplierBranches() {
        LOGGER.debug("Get all organizations branches");
        List<Organization> organizationList = organizationService.findAllWithHeadIdNotNullAndOrgTypeSupplier();
        LOGGER.debug("Got all organizations branches: " + organizationList.size());
        return organizationList;
    }


}
