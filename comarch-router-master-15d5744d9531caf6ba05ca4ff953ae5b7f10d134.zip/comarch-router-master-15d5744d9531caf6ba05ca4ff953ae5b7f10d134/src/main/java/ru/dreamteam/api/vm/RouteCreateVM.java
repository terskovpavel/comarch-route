package ru.dreamteam.api.vm;

import ru.dreamteam.model.OrgRoute;
import ru.dreamteam.model.Route;

import java.util.List;

/**
 * Класс для создания нового объекта Route, получаемоего с frondend
 */
public class RouteCreateVM {

    private String tcId;
    private String supplierId;
    private List<Route> routes;
    private List<OrgRoute.DocType> docTypes;

    public List<OrgRoute.DocType> getDocTypes() {
        return docTypes;
    }

    public void setDocTypes(List<OrgRoute.DocType> docTypes) {
        this.docTypes = docTypes;
    }

    public String getTcId() {
        return tcId;
    }

    public void setTcId(String tcId) {
        this.tcId = tcId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public List<Route> getRoutes() {
        return routes;
    }

    public void setRoutes(List<Route> routes) {
        this.routes = routes;
    }
}
