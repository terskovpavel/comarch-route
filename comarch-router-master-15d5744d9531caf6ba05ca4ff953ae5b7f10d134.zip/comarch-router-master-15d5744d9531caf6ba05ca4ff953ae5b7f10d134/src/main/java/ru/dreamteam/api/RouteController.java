package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.model.Route;
import ru.dreamteam.service.RouteService;

import java.util.List;

@RestController
@RequestMapping(value = "/route")
public class RouteController {
    private final static Logger LOGGER = Logger.getLogger(RouteController.class);
    @Autowired
    private RouteService routeService;

    /**
     * Возвращает все Route из базы данных
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Route> getRoutes() {
        LOGGER.debug("Get all routes");
        List<Route> routeList = routeService.findAll();
        LOGGER.debug("Got all routes, size of list: " + routeList.size());
        return routeList;
    }

    /**
     * Удаляет Route из базы данных
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteRoute(@PathVariable String id) {
        LOGGER.debug("Delete route request");
        Route route = routeService.delete(id);
        LOGGER.info("Deleted route: " + route);
    }

    /**
     * Обновляет Route в базе данных
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void updateRoute(@RequestBody Route route) {
        LOGGER.debug("Update route request");
        Route updatedRoute = routeService.update(route);
        LOGGER.info("Updated route: " + updatedRoute);
    }

    /**
     * Возвращает все Route по orgRouteId из базы данных
     */
    @RequestMapping(value = "/all/{orgRouteId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Route> getRoutesByOrgRouteId(@PathVariable String orgRouteId) {
        LOGGER.debug("Get all routes by org route id - " + orgRouteId);
        List<Route> routeList = routeService.findByOrgRouteId(orgRouteId);
        LOGGER.debug("Got all routes by org route, size of list: " + routeList.size());
        return routeList;
    }

    /**
     * Пагинация Route по orgRouteId
     */
    @RequestMapping(value = "/page/{pageNumber}/orgRoute/{orgRouteId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<Route> getRoutesByPage(@PathVariable int pageNumber, @PathVariable String orgRouteId) {
        LOGGER.debug("Get all routes by page - #" + pageNumber);
        List<Route> routeList = routeService.findByOrgRouteIdPageble(orgRouteId, pageNumber);
        LOGGER.debug("Got all routes by page, size of list: " + routeList.size());
        return routeList;
    }

}
