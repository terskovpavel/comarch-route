package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.model.FTP;
import ru.dreamteam.service.FtpService;

import java.util.List;

@RestController
@RequestMapping(value = "/ftp")
public class FTPController {
    private final static Logger LOGGER = Logger.getLogger(FTPController.class);
    @Autowired
    private FtpService ftpService;

    /**
     * Возвращает все FTP из базы данных
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<FTP> getFTPs() {
        LOGGER.debug("Get all ftp's");
        List<FTP> ftpList = ftpService.findAll();
        LOGGER.debug("Got all ftp's, size of list: " + ftpList.size());
        return ftpList;
    }

    /**
     * Возвращает FTP по id из базы данных
     */
    @RequestMapping(value = "/{ftpId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public FTP getFTP(@PathVariable String ftpId) {
        LOGGER.debug("Get ftp");
        FTP ftp = ftpService.findOne(ftpId);
        LOGGER.debug("Got ftp: " + ftp);
        return ftp;
    }


    /**
     * Удаляет FTP из базы данных
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteFTP(@PathVariable String id) {
        LOGGER.debug("Delete ftp request");
        FTP ftp = ftpService.delete(id);
        LOGGER.info("Deleted ftp: " + ftp);
    }

    /**
     * Обновляет FTP в базе данных
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void updateFTP(@RequestBody FTP ftp) {
        LOGGER.debug("Update ftp request");
        FTP updatedFTP = ftpService.update(ftp);
        LOGGER.info("Updated ftp: " + updatedFTP);
    }

    /**
     * Пагинация FTP
     */
    @RequestMapping(value = "/page/{pageNumber}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<FTP> getFTPByPage(@PathVariable int pageNumber) {
        LOGGER.debug("Get all ftp's by page - #" + pageNumber);
        List<FTP> ftpList = ftpService.getByPage(pageNumber);
        LOGGER.debug("Got all ftp's by page, size of list: " + ftpList.size());
        return ftpList;
    }
}
