package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.model.TrackInfo;
import ru.dreamteam.service.TrackInfoService;
import ru.dreamteam.utils.DateUtils;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value = "/trackInfo")
public class TrackInfoController {

    @Autowired
    private TrackInfoService trackInfoService;

    private final static Logger LOGGER = Logger.getLogger(TrackInfoController.class);

    /**
     * Возвращает все TrackInfo из базы данных
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<TrackInfo> getTrackInfo() {
        LOGGER.debug("Get all track info");
        List<TrackInfo> trackInfoList = trackInfoService.findAll();
        LOGGER.debug("Got all track info, size of list: " + trackInfoList.size());
        return trackInfoList;
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Long getCount() {
        return trackInfoService.getAllCount();
    }

    /**
     * Возвращает TrackInfo по id из базы данных
     */
    @RequestMapping(value = "/{trackInfoId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public TrackInfo getTrackInfo(@PathVariable String trackInfoId) {
        LOGGER.debug("Get track info");
        TrackInfo trackInfo = trackInfoService.findOne(trackInfoId);
        LOGGER.debug("Got track info: " + trackInfo);
        return trackInfo;
    }

    /**
     * Созадаёт TrackInfo в базе данных
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void createTrackInfo(@RequestParam TrackInfo.DocType docType, @RequestParam Date date, @RequestParam String number, @RequestParam String glnReceiver) {
        LOGGER.debug("Create track info request");
        TrackInfo trackInfo = trackInfoService.create(docType, date, number, glnReceiver, null);
        LOGGER.info("Created new track info: " + trackInfo);
    }

    /**
     * Удаляет TrackInfo из базы данных
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteTrackInfo(@RequestParam String trackInfoId) {
        LOGGER.debug("Delete track info request");
        TrackInfo trackInfo = trackInfoService.delete(trackInfoId);
        LOGGER.info("Deleted track info: " + trackInfo);
    }

    /**
     * Обновляет TrackInfo в базе данных
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void updateTrackInfo(@RequestParam TrackInfo trackInfo) {
        LOGGER.debug("Update track info request");
        TrackInfo updatedTrackInfo = trackInfoService.update(trackInfo);
        LOGGER.info("Updated track info: " + updatedTrackInfo);
    }

    /**
     * Пагинация TrackInfo
     */
    @RequestMapping(value = "/page/{pageNumber}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<TrackInfo> getTrackInfoByPageAndFilter(@PathVariable int pageNumber,
                                                       @RequestParam(required = false) String docType,
                                                       @RequestParam(required = false) String number,
                                                       @RequestParam(required = false) String gln,
                                                       @RequestParam(required = false) String trackingId,
                                                       @RequestParam(required = false) Boolean status,
                                                       @RequestParam(required = false) String startDate,
                                                       @RequestParam(required = false) String endDate) throws ParseException {
        LOGGER.debug("Get filter track info by page - #" + pageNumber);
        Date startDt = DateUtils.getForattedString(startDate);
        Date endDt = DateUtils.getForattedString(endDate);
        List<TrackInfo> trackInfoList = trackInfoService.findByPageAndFilter(pageNumber, docType, number, gln, trackingId, status, startDt, endDt);
        LOGGER.debug("Got filter track info by page, size of list: " + trackInfoList.size());
        return trackInfoList;
    }

    /**
     * Пагинация TrackInfo
     */
    @RequestMapping(value = "/page/count", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Long getCountTrackInfoByPageAndFilter(@RequestParam(required = false) String docType,
                                                 @RequestParam(required = false) String number,
                                                 @RequestParam(required = false) String gln,
                                                 @RequestParam(required = false) String trackingId,
                                                 @RequestParam(required = false) Boolean status,
                                                 @RequestParam(required = false) String startDate,
                                                 @RequestParam(required = false) String endDate) throws ParseException {
        LOGGER.debug("Get count filter track info");
        Date startDt = DateUtils.getForattedString(startDate);
        Date endDt = DateUtils.getForattedString(endDate);
        Long count = trackInfoService.countByPageAndFilter(docType, number, gln, trackingId, status, startDt, endDt);
        LOGGER.debug("Got count filter track info by page");
        return count;
    }

}
