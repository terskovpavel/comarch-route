package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.dreamteam.api.vm.RouteCreateVM;
import ru.dreamteam.api.vm.RouteUpdateVM;
import ru.dreamteam.model.OrgRoute;
import ru.dreamteam.model.Organization;
import ru.dreamteam.model.Route;
import ru.dreamteam.model.User;
import ru.dreamteam.service.ExcelService;
import ru.dreamteam.service.OrgRouteService;
import ru.dreamteam.service.OrganizationService;
import ru.dreamteam.service.RouteService;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/orgRoute")
public class OrgRouteController {
    private final static Logger LOGGER = Logger.getLogger(OrgRouteController.class);
    @Autowired
    private OrgRouteService orgRouteService;
    @Autowired
    private OrganizationService organizationService;
    @Autowired
    private RouteService routeService;

    @Autowired
    private ExcelService excelService;


    /**
     * Возвращает все OrgRoute из базы данных
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<OrgRoute> getOrgRoutes() {
        LOGGER.debug("Get all org routes");
        List<OrgRoute> orgRouteList = orgRouteService.findAll();
        LOGGER.debug("Got all org routes, size of list: " + orgRouteList.size());
        return orgRouteList;
    }

    /**
     * Возвращает все филлиалы для OrgRoute
     */
    @RequestMapping(value = "/branches/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Map<String, List<Organization>> getBranches(@PathVariable String id) {
        LOGGER.debug("Get branches for org routes " + id);
        OrgRoute orgRoute = orgRouteService.findOne(id);
        List<Organization> tcs = organizationService.organizationsByHeadId(orgRoute.getTsId());
        List<Organization> suppliers = organizationService.organizationsByHeadId(orgRoute.getSupplierId());
        Map<String, List<Organization>> result = new HashMap<>();
        result.put("tcs", tcs);
        result.put("suppliers", suppliers);
        return result;
    }

    /**
     * Возвращает OrgRoute по id из базы данных
     */
    @RequestMapping(value = "/{orgRouteId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public OrgRoute getOrgRoute(@PathVariable String orgRouteId) {
        LOGGER.debug("Get org route");
        OrgRoute orgRoute = orgRouteService.findOne(orgRouteId);
        LOGGER.debug("Got org route: " + orgRoute);
        return orgRoute;
    }

    /**
     * Созадаёт OrgRoute в базе данных
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public OrgRoute createOrgRoute(@RequestBody RouteCreateVM routeCreateVM, HttpSession httpSession) {
        LOGGER.debug("Create route request");
        Organization tcOrg = organizationService.findOne(routeCreateVM.getTcId());
        Organization supplierOrg = organizationService.findOne(routeCreateVM.getSupplierId());
        String userName = ((User) httpSession.getAttribute("user")).getUsername();

        OrgRoute orgRoute = orgRouteService.create(tcOrg.getId(), supplierOrg.getId(), new Date(), null, routeCreateVM.getDocTypes(), userName);
        for (Route route : routeCreateVM.getRoutes()) {
            route.setOrgRouteId(orgRoute.getId());
            routeService.create(route);
        }
        LOGGER.info("Created new orgRoute: " + orgRoute);
        return orgRoute;
    }

    /**
     * Обновляет OrgRoute в базе данных
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public OrgRoute updateOrgRoute(@RequestBody RouteUpdateVM routeUpdateVM, HttpSession httpSession) {
        LOGGER.debug("Update route request");
        String userName = ((User) httpSession.getAttribute("user")).getUsername();

        OrgRoute orgRoute = orgRouteService.findOne(routeUpdateVM.getId());
        orgRoute.setDocTypes(routeUpdateVM.getDocTypes());
        orgRoute.setSupplierId(routeUpdateVM.getSupplierId());
        orgRoute.setTsId(routeUpdateVM.getTcId());
        orgRoute.setUserName(userName);
        orgRouteService.update(orgRoute);

        for (Route route : routeUpdateVM.getRoutes()) {
            route.setOrgRouteId(orgRoute.getId());
            if (route.getId() == null) {
                routeService.create(route);
            } else {
                routeService.update(route);
            }
        }
        LOGGER.info("Updater new orgRoute: " + orgRoute);
        return orgRoute;
    }

    /**
     * Загружает объект Route из файла excel
     */
    @RequestMapping(value = "/excel/parseRoutes/{orgRouteId}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void excelParse(@RequestParam MultipartFile file, @PathVariable String orgRouteId) throws IOException {
        List<Route> routes = excelService.parseRoutesXLSX(file.getInputStream());
        for (Route route : routes) {
            route.setOrgRouteId(orgRouteId);
            routeService.create(route);
        }
    }


    /**
     * Удаляет OrgRoute из базы данных
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteOrgRoute(@PathVariable String id) {
        LOGGER.debug("Delete org route request");
        List<Route> routes = routeService.findByOrgRouteId(id);
        for (Route route : routes) {
            routeService.delete(route.getId());
        }
        OrgRoute orgRoute = orgRouteService.delete(id);
        LOGGER.info("Deleted org route: " + orgRoute);
    }

    /**
     * Пагинация OrgRoute
     */
    @RequestMapping(value = "/page/{pageNumber}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<OrgRoute> getOrgRoutesByPage(@PathVariable int pageNumber) {
        LOGGER.debug("Get all org routes by page - #" + pageNumber);
        List<OrgRoute> orgRouteList = orgRouteService.getByPage(pageNumber);
        LOGGER.debug("Got all org routes by page, size of list: " + orgRouteList.size());
        return orgRouteList;
    }

}
