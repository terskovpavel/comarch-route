package ru.dreamteam.api;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.api.vm.ResponseVM;
import ru.dreamteam.model.User;
import ru.dreamteam.service.UserService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping(value = "/users")
public class UsersController {
    private final static Logger LOGGER = Logger.getLogger(UsersController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder encoder;

    /**
     * Возвращает всех Пользователей из базы
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public List<User> allUsers() {
        LOGGER.debug("Get all users");
        List<User> users = userService.findAll();
        LOGGER.debug("Got users " + users);
        return users;
    }

    /**
     *  Удаляет Пользователя из базы по id
     */
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void deleteUser(@PathVariable String id) {
        LOGGER.debug("Delete user request");
        User user = userService.delete(id);
        LOGGER.info("Deleted user: " + user);
    }


}
