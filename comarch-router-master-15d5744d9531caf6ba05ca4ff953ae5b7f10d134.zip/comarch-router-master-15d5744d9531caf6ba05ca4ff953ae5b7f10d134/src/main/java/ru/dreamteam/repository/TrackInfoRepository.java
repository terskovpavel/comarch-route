package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.TrackInfo;
import ru.dreamteam.repository.impl.TrackInfoRepositoryCustom;

import java.util.List;

public interface TrackInfoRepository extends MongoRepository<TrackInfo, String>, TrackInfoRepositoryCustom {

    List<TrackInfo> findByTrackingId(String trackingId);

}
