package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.Route;
import ru.dreamteam.repository.impl.RouteRepositoryCustom;

public interface RouteRepository extends MongoRepository<Route, String>, RouteRepositoryCustom {

}
