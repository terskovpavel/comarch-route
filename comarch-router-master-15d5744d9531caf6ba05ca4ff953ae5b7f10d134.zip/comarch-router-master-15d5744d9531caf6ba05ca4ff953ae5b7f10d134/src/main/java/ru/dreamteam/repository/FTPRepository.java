package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.FTP;
import ru.dreamteam.repository.impl.FTPRepositoryCustom;

public interface FTPRepository extends MongoRepository<FTP, String>,FTPRepositoryCustom {
}
