package ru.dreamteam.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import ru.dreamteam.model.Route;

import java.util.List;

public class RouteRepositoryImpl implements RouteRepositoryCustom {
    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Найти все подмаршруты по id маршрута
     */
    @Override
    public List<Route> findByOrgRouteId(String orgRouteId) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("orgRouteId").is(orgRouteId)));
        List<Route> routes = mongoTemplate.find(query, Route.class);
        return routes;
    }

    /**
     * Найти все подмаршруты по id маршрута с пагинацией
     */
    @Override
    public List<Route> findByOrgRouteIdPageble(String orgRouteId, int skip, int limit) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("orgRouteId").is(orgRouteId))).skip(skip).limit(limit);
        List<Route> routes = mongoTemplate.find(query, Route.class);
        return routes;
    }

    /**
     * Найти Подмаршрут где receiver = sellerIln и routingSender = buyer
     */
    @Override
    public Route findByReceiverAndRoutingSender(String sellerIln, String buyerIln) {
        Query query = new Query(new Criteria().andOperator(
                Criteria.where("receiver").is(sellerIln),
                Criteria.where("routingSender").is(buyerIln)));
        List<Route> routes = mongoTemplate.find(query, Route.class);
        if (routes != null && !routes.isEmpty()) {
            return routes.get(0);
        }
        return null;
    }
}
