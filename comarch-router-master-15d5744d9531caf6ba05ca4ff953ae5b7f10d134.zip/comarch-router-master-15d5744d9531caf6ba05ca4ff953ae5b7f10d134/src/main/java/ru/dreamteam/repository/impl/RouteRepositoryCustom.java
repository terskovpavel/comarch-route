package ru.dreamteam.repository.impl;

import ru.dreamteam.model.Route;

import java.util.List;

public interface RouteRepositoryCustom {
    List<Route> findByOrgRouteId(String orgRouteId);

    List<Route> findByOrgRouteIdPageble(String orgRouteId, int skip, int limit);

    Route findByReceiverAndRoutingSender(String sellerIln, String buyerIln);
}
