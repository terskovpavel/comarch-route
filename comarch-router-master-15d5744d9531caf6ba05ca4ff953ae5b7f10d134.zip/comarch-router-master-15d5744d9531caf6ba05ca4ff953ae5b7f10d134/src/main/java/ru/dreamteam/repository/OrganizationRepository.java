package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.Organization;
import ru.dreamteam.repository.impl.OrganizationRepositoryCustom;

public interface OrganizationRepository extends MongoRepository<Organization, String>, OrganizationRepositoryCustom {
}