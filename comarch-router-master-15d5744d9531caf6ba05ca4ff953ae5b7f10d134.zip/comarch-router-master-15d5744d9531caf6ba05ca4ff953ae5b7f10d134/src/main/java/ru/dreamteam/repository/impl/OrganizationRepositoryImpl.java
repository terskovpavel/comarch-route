package ru.dreamteam.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import ru.dreamteam.model.Organization;

import java.util.ArrayList;
import java.util.List;

public class OrganizationRepositoryImpl implements OrganizationRepositoryCustom {
    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Все Organization по headId
     */
    @Override
    public List<Organization> organizationsByHeadId(String headId) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("headId").is(headId)));
        List<Organization> organizations = mongoTemplate.find(query, Organization.class);
        if (organizations == null) {
            return new ArrayList<>();
        }
        return organizations;
    }

    /**
     * Найти все Головные офисы поставщиков
     */
    @Override
    public List<Organization> findAllWithHeadIdNotNullAndOrgTypeSupplier() {
        Query query = new Query(new Criteria().andOperator(Criteria.where("headId").exists(true),
                Criteria.where("orgType").is(Organization.ORG_TYPE.SUPPLIER.name())));
        List<Organization> organizations = mongoTemplate.find(query, Organization.class);
        return organizations;
    }

    @Override
    public List<Organization> findByOrgType(String orgType) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("orgType").is(orgType)));
        List<Organization> organizations = mongoTemplate.find(query, Organization.class);
        return organizations;
    }

    /**
     * Найти Organization по gln
     */
    @Override
    public Organization findByGln(String gln) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("gln").is(gln)));
        Organization organization = mongoTemplate.findOne(query, Organization.class);
        return organization;
    }

    @Override
    public List<Organization> findByOrgTypeAndPageNumber(String orgType, Pageable pageRequest) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("orgType").is(orgType)));
        query.with(pageRequest);
        List<Organization> organizations = mongoTemplate.find(query, Organization.class);
        return organizations;
    }
}
