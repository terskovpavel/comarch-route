package ru.dreamteam.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import ru.dreamteam.model.TrackInfo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TrackInfoRepositoryImpl implements TrackInfoRepositoryCustom {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public TrackInfo findByTrackingIdAndType(String trackingId, TrackInfo.DocType docType) {
        Query query = new Query(new Criteria().andOperator(
                Criteria.where("docType").is(docType.name()),
                Criteria.where("trackingId").is(trackingId)));
        List<TrackInfo> trackInfos = mongoTemplate.find(query, TrackInfo.class);
        if (trackInfos != null && !trackInfos.isEmpty()) {
            return trackInfos.get(0);
        }
        return null;
    }

    @Override
    public List<TrackInfo> findByPageAndFilter(Pageable pageNumber, String docType, String number, String gln, String trackingId, Boolean status, Date startDate, Date endDate) {
        List<Criteria> criterias = new ArrayList<>();
        if (docType != null && !docType.equals("")) {
            criterias.add(Criteria.where("docType").is(docType));
        }
        if (number != null && !number.equals("")) {
            criterias.add(Criteria.where("docNumber").regex(number));
        }
        if (gln != null && !gln.equals("")) {
            criterias.add(Criteria.where("glnReceiver").regex(gln));
        }
        if (trackingId != null && !trackingId.equals("")) {
            criterias.add(Criteria.where("trackingId").regex(trackingId));
        }
        if (status != null) {
            criterias.add(Criteria.where("successful").is(status));
        }
        if (startDate != null) {
            criterias.add(Criteria.where("date").gte(startDate));
        }
        if (endDate != null) {
            criterias.add(Criteria.where("date").lte(endDate));
        }
        Criteria criteria = new Criteria();
        if (criterias.isEmpty()) {
            Query query = new Query();
            query.with(pageNumber);
            return mongoTemplate.find(query, TrackInfo.class);
        } else {
            criteria.andOperator(criterias.toArray(new Criteria[criterias.size()]));
            Query query = new Query(criteria);
            query.with(pageNumber);
            return mongoTemplate.find(query, TrackInfo.class);
        }
    }

    @Override
    public Long countByPageAndFilter(String docType, String number, String gln, String trackingId, Boolean status, Date startDate, Date endDate) {
        List<Criteria> criterias = new ArrayList<>();
        if (docType != null && !docType.equals("")) {
            criterias.add(Criteria.where("docType").is(docType));
        }
        if (number != null && !number.equals("")) {
            criterias.add(Criteria.where("docNumber").regex(number));
        }
        if (gln != null && !gln.equals("")) {
            criterias.add(Criteria.where("glnReceiver").regex(gln));
        }
        if (trackingId != null && !trackingId.equals("")) {
            criterias.add(Criteria.where("trackingId").regex(trackingId));
        }
        if (status != null) {
            criterias.add(Criteria.where("successful").is(status));
        }
        if (startDate != null) {
            criterias.add(Criteria.where("date").gte(startDate));
        }
        if (endDate != null) {
            criterias.add(Criteria.where("date").lte(endDate));
        }
        Criteria criteria = new Criteria();
        if (criterias.isEmpty()) {
            Query query = new Query();
            return mongoTemplate.count(query, TrackInfo.class);
        } else {
            criteria.andOperator(criterias.toArray(new Criteria[criterias.size()]));
            Query query = new Query(criteria);
            return mongoTemplate.count(query, TrackInfo.class);
        }
    }
}
