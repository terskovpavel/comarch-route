package ru.dreamteam.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import ru.dreamteam.model.FTP;

import java.util.List;

public class FTPRepositoryImpl implements FTPRepositoryCustom {
    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Найти FTP по supplierId
     */
    @Override
    public FTP findBySupplier(String headId) {
        Query query = new Query(new Criteria().andOperator(Criteria.where("supplierId").is(headId)));
        List<FTP> ftps = mongoTemplate.find(query, FTP.class);
        if (ftps != null && !ftps.isEmpty()) {
            return ftps.get(0);
        }
        return null;
    }

}
