package ru.dreamteam.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import ru.dreamteam.model.OrgRoute;

import java.util.List;

public class OrgRouteRepositoryCustomImpl implements OrgRouteRepositoryCustom {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Найти все OrgRoute определенного docType
     */
    @Override
    public List<OrgRoute> findAllByDocTypes(OrgRoute.DocType docType) {
        Query query = new Query(new Criteria().where("docTypes").in(docType.name()));
        return mongoTemplate.find(query, OrgRoute.class);
    }

}
