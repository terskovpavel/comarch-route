package ru.dreamteam.repository.impl;

import ru.dreamteam.model.OrgRoute;

import java.util.List;

/**
 * Created by kiv1n on 12-Dec-16.
 */
public interface OrgRouteRepositoryCustom {

    List<OrgRoute> findAllByDocTypes(OrgRoute.DocType docType);

}
