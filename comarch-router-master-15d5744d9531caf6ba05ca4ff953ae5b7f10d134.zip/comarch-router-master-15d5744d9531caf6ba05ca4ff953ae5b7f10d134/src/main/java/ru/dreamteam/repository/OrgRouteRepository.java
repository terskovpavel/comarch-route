package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.OrgRoute;
import ru.dreamteam.repository.impl.OrgRouteRepositoryCustom;

public interface OrgRouteRepository extends MongoRepository<OrgRoute, String>, OrgRouteRepositoryCustom {
}
