package ru.dreamteam.repository.impl;

import org.springframework.data.domain.Pageable;
import ru.dreamteam.model.Organization;

import java.util.List;

public interface OrganizationRepositoryCustom {

    List<Organization> organizationsByHeadId(String headId);

    List<Organization> findAllWithHeadIdNotNullAndOrgTypeSupplier();

    List<Organization> findByOrgType(String orgType);

    Organization findByGln(String gln);

    List<Organization> findByOrgTypeAndPageNumber(String orgType, Pageable pageRequest);
}
