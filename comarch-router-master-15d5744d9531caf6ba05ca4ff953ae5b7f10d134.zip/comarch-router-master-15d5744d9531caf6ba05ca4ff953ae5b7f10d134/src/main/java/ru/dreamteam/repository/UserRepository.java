package ru.dreamteam.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import ru.dreamteam.model.User;

/**
 * Created by kiv1n on 05-Dec-16.
 */
public interface UserRepository extends MongoRepository<User, String> {

    User findByUsername(String username);

}
