package ru.dreamteam.repository.impl;

import ru.dreamteam.model.FTP;

public interface FTPRepositoryCustom {

    FTP findBySupplier(String headId);
}
