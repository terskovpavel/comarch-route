package ru.dreamteam.repository.impl;

import org.springframework.data.domain.Pageable;
import ru.dreamteam.model.TrackInfo;

import java.util.Date;
import java.util.List;

public interface TrackInfoRepositoryCustom {

    TrackInfo findByTrackingIdAndType(String trackingId, TrackInfo.DocType docType);

    List<TrackInfo> findByPageAndFilter(Pageable pageNumber, String docType,
                                        String number, String gln,
                                        String trackingId, Boolean status, Date startDate, Date endDate);

    Long countByPageAndFilter(String docType,
                                        String number, String gln,
                                        String trackingId, Boolean status, Date startDate, Date endDate);
}
