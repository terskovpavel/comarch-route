package ru.dreamteam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import ru.dreamteam.model.User;

import javax.servlet.http.HttpSession;

@Controller
public class PagesController {

    @RequestMapping(value = "/tracking", method = RequestMethod.GET)
    public String getTrackInfoPage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "tracking";
    }

    @RequestMapping(value = "/organizations_supplier", method = RequestMethod.GET)
    public String getOrgSupplierPage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "organizations_supplier";
    }
    @RequestMapping(value = "/organizations_tc", method = RequestMethod.GET)
    public String getOrgTCPage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "organizations_tc";
    }


    @RequestMapping(value = "/ftp", method = RequestMethod.GET)
    public String getFtpPage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "ftp";
    }

    @RequestMapping(value = "/route/{id}", method = RequestMethod.GET)
    public String getCreateRoutePage(@PathVariable String id, HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "route";
    }

    @RequestMapping(value = "/org_route_create", method = RequestMethod.GET)
    public String getCreateOrgRoutePage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "org_route_create";
    }

    @RequestMapping(value = "/org_route", method = RequestMethod.GET)
    public String getOrgRotePage(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "org_route";
    }

    @RequestMapping(value = "/org_route_edit/{id}", method = RequestMethod.GET)
    public String getOrgRoteEditPage(@PathVariable String id, HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "org_route_edit";
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getIndex(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "organizations_supplier";
    }

    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public String getUsers(HttpSession httpSession, Model model) {
        model.addAttribute("username", ((User) httpSession.getAttribute("user")).getUsername());
        model.addAttribute("isAdmin", ((User) httpSession.getAttribute("user")).isAdmin());
        return "users";
    }
}
