package ru.dreamteam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.dreamteam.api.vm.ResponseVM;
import ru.dreamteam.model.User;
import ru.dreamteam.service.UserService;

import javax.servlet.http.HttpServletRequest;

@Controller
public class AuthController {

    public static final String SIGN_IN_ERROR_MESSAGE = "Неверные логин или пароль";
    public static final String SIGN_IN_FAILURE_REDIRECT_URL = "/login?error=true";

    @Autowired
    private UserService userService;
    @Autowired
    private PasswordEncoder encoder;

    @RequestMapping(value = "login", method = RequestMethod.GET)
    public String signInPage(@RequestParam(required = false) String error,
                             HttpServletRequest request,
                             Model model) {
        // Проверка на авторизацию пользователя
        if (request.getSession().getAttribute("user") != null) {
            return "redirect:/";
        }
        // Добавление ошибки
        if (error != null) {
            model.addAttribute("error", SIGN_IN_ERROR_MESSAGE);
        }
        return "login";
    }


    @RequestMapping(value = "registration", method = RequestMethod.POST)
    @ResponseBody
    public ResponseVM<User> registration(HttpServletRequest request,
                                         @RequestBody User user) {

        ResponseVM<User> response = new ResponseVM<>();

        if (user.getId() != null) {
            userService.update(user);
            response.setCode("200");
            response.setT(user);
            return response;
        }


        // Check that username is not used
        User foundUser = userService.findByUsername(user.getUsername());
        if (foundUser != null) {
            response.setError("Username already in user");
            response.setCode("1000");
            return response;
        }

        // Save user
        User savedUser = userService.save(new User(user.getUsername(), encoder.encode(user.getPassword())));
        response.setT(savedUser);
        response.setCode("200");
        return response;
    }


}
