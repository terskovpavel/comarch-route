package ru.dreamteam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import ru.dreamteam.model.TrackInfo;
import ru.dreamteam.service.TrackInfoService;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping(value = "/download")
public class FileDownloaderController {

    @Autowired
    private TrackInfoService trackInfoService;
    //Возвращает файл xml
    @RequestMapping(value = "trackInfo/{trackInfoId}/originalXml", method = RequestMethod.GET)
    public void downloadTrackInfoOriginalXml(@PathVariable String trackInfoId,
                                  HttpServletResponse response) throws Exception {

        TrackInfo trackInfo = trackInfoService.findOne(trackInfoId);
        // Check trackInfo existence
        if (trackInfo == null) {
            throw new Exception("Object with specified ID is not found");
        }
        // Check trackInfo originalXML
        if (trackInfo.getOriginalXml() == null) {
            throw new Exception("Original XML of track info with specified ID is not found");
        }

        putXmlStringToHttpResponse(trackInfo.getOriginalXml(),
                String.format("attachment;filename=trackInfo-%s-originalXml.xml", trackInfoId), response);
    }
    //Возвращает файл xml
    @RequestMapping(value = "trackInfo/{trackInfoId}/replacedXml", method = RequestMethod.GET)
    public void downloadTrackInfoReplacedXml(@PathVariable String trackInfoId,
                                  HttpServletResponse response) throws Exception {

        TrackInfo trackInfo = trackInfoService.findOne(trackInfoId);
        // Check trackInfo existence
        if (trackInfo == null) {
            throw new Exception("Object with specified ID is not found");
        }
        // Check trackInfo originalXML
        if (trackInfo.getReplacedXml() == null) {
            throw new Exception("Replaced XML of track info with specified ID is not found");
        }

        putXmlStringToHttpResponse(trackInfo.getReplacedXml(),
                String.format("attachment;filename=trackInfo-%s-replacedXml.xml", trackInfoId), response);
    }

    private void putXmlStringToHttpResponse(String xmlString, String xmlFileName, HttpServletResponse httpResponse) throws IOException {
        httpResponse.setContentType("application/xml");
        httpResponse.setHeader("Content-Disposition", xmlFileName);
        ServletOutputStream outStream = httpResponse.getOutputStream();
        outStream.write(xmlString.getBytes("UTF-8"));
        outStream.flush();
        outStream.close();
    }

}
