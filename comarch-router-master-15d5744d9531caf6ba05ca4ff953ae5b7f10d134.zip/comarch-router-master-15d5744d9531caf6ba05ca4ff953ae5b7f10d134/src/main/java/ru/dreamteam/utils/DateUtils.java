package ru.dreamteam.utils;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    private final static String FORMAT = "yyyyMMddHHmmss";

    /**
     * Получение даты формата FORMAT
     */
    public static String getFormattedString(DateTime dateTime) {
        DateTimeFormatter fmt = DateTimeFormat.forPattern(FORMAT);
        return dateTime.toString(fmt);
    }

    public static Date getForattedString(String date) throws ParseException {
        if(date == null || date.isEmpty()) {
            return null;
        }
        DateFormat format = new SimpleDateFormat("dd/mm/yy");
        return format.parse(date);
    }
}
