package ru.dreamteam.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "organization")
public class Organization {

    private String id;
    private String name;
    private String login;
    private String gln;
    private String password;
    private ORG_TYPE orgType;
    private String headId;

    public Organization() {
    }

    public Organization(String name, ORG_TYPE orgType, String headId, String password, String gln, String login) {
        this.name = name;
        this.orgType = orgType;
        this.headId = headId;
        this.password = password;
        this.gln = gln;
        this.login = login;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getGln() {
        return gln;
    }

    public void setGln(String gln) {
        this.gln = gln;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ORG_TYPE getOrgType() {
        return orgType;
    }

    public void setOrgType(ORG_TYPE orgType) {
        this.orgType = orgType;
    }

    public String getHeadId() {
        return headId;
    }

    public void setHeadId(String headId) {
        this.headId = headId;
    }

    @Override
    public String toString() {
        return "Organization{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", orgType=" + orgType +
                ", headId='" + headId + '\'' +
                '}';
    }

    public enum ORG_TYPE {
        TC, SUPPLIER
    }
}
