package ru.dreamteam.model.soap.receive;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "Document-ReceivingAdvice")
@XmlAccessorType(XmlAccessType.FIELD)
public class DocumentRecAdv {

    @XmlElement(name = "ReceivingAdvice-Header")
    private ReceivingAdviceHeader receivingAdviceHeader;
    @XmlElement(name = "ReceivingAdvice-Reference")
    private ReceivingAdviceReference receivingAdviceReference;
    @XmlElement(name = "ReceivingAdvice-Parties")
    private ReceivingAdviceParties receivingAdviceParties;
    @XmlElement(name = "ReceivingAdvice-Lines")
    private ReceivingAdviceLines receivingAdviceLines;
    @XmlElement(name = "ReceivingAdvice-Summary")
    private ReceivingAdviceSummary receivingAdviceSummary;

    public ReceivingAdviceHeader getReceivingAdviceHeader() {
        return receivingAdviceHeader;
    }

    public void setReceivingAdviceHeader(ReceivingAdviceHeader receivingAdviceHeader) {
        this.receivingAdviceHeader = receivingAdviceHeader;
    }

    public ReceivingAdviceReference getReceivingAdviceReference() {
        return receivingAdviceReference;
    }

    public void setReceivingAdviceReference(ReceivingAdviceReference receivingAdviceReference) {
        this.receivingAdviceReference = receivingAdviceReference;
    }

    public ReceivingAdviceParties getReceivingAdviceParties() {
        return receivingAdviceParties;
    }

    public void setReceivingAdviceParties(ReceivingAdviceParties receivingAdviceParties) {
        this.receivingAdviceParties = receivingAdviceParties;
    }

    public ReceivingAdviceLines getReceivingAdviceLines() {
        return receivingAdviceLines;
    }

    public void setReceivingAdviceLines(ReceivingAdviceLines receivingAdviceLines) {
        this.receivingAdviceLines = receivingAdviceLines;
    }

    public ReceivingAdviceSummary getReceivingAdviceSummary() {
        return receivingAdviceSummary;
    }

    public void setReceivingAdviceSummary(ReceivingAdviceSummary receivingAdviceSummary) {
        this.receivingAdviceSummary = receivingAdviceSummary;
    }

    @XmlRootElement(name = "ReceivingAdvice-Header")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceHeader {

        @XmlElement(name = "ReceivingAdviceNumber")
        private String ReceivingAdviceNumber;
        @XmlElement(name = "ReceivingAdviceDate")
        private String ReceivingAdviceDate;
        @XmlElement(name = "GoodsReceiptDate")
        private String GoodsReceiptDate;

        public String getReceivingAdviceNumber() {
            return ReceivingAdviceNumber;
        }

        public void setReceivingAdviceNumber(String receivingAdviceNumber) {
            ReceivingAdviceNumber = receivingAdviceNumber;
        }

        public String getReceivingAdviceDate() {
            return ReceivingAdviceDate;
        }

        public void setReceivingAdviceDate(String receivingAdviceDate) {
            ReceivingAdviceDate = receivingAdviceDate;
        }

        public String getGoodsReceiptDate() {
            return GoodsReceiptDate;
        }

        public void setGoodsReceiptDate(String goodsReceiptDate) {
            GoodsReceiptDate = goodsReceiptDate;
        }
    }

    @XmlRootElement(name = "ReceivingAdvice-Reference")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceReference {

        @XmlElement(name = "Order")
        private Order order;

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        @XmlRootElement(name = "Order")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Order {
            @XmlElement(name = "BuyerOrderNumber")
            private String buyerOrderNumber;

            public String getBuyerOrderNumber() {
                return buyerOrderNumber;
            }

            public void setBuyerOrderNumber(String buyerOrderNumber) {
                this.buyerOrderNumber = buyerOrderNumber;
            }
        }

        @XmlRootElement(name = "DeliveryNote")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryNote {
            @XmlElement(name = "DeliveryNoteNumber")
            private String deliveryNoteNumber;

            public String getDeliveryNoteNumber() {
                return deliveryNoteNumber;
            }

            public void setDeliveryNoteNumber(String deliveryNoteNumber) {
                this.deliveryNoteNumber = deliveryNoteNumber;
            }
        }

        @XmlRootElement(name = "InternalDocument")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class InternalDocument {
            @XmlElement(name = "InternalDocumentNumber")
            private String internalDocumentNumber;

            public String getInternalDocumentNumber() {
                return internalDocumentNumber;
            }

            public void setInternalDocumentNumber(String internalDocumentNumber) {
                this.internalDocumentNumber = internalDocumentNumber;
            }
        }

    }

    @XmlRootElement(name = "ReceivingAdvice-Parties")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceParties {

        @XmlElement(name = "Buyer")
        private Buyer buyer;
        @XmlElement(name = "Seller")
        private Seller seller;
        @XmlElement(name = "DeliveryPoint")
        private DeliveryPoint deliveryPoint;

        @XmlRootElement(name = "Buyer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Buyer {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "Seller")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Seller {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "DeliveryPoint")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryPoint {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        public Buyer getBuyer() {
            return buyer;
        }

        public void setBuyer(Buyer buyer) {
            this.buyer = buyer;
        }

        public Seller getSeller() {
            return seller;
        }

        public void setSeller(Seller seller) {
            this.seller = seller;
        }

        public DeliveryPoint getDeliveryPoint() {
            return deliveryPoint;
        }

        public void setDeliveryPoint(DeliveryPoint deliveryPoint) {
            this.deliveryPoint = deliveryPoint;
        }
    }

    @XmlRootElement(name = "ReceivingAdvice-Lines")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceLines {

        @XmlElement(name = "Line")
        private List<Line> lines;

        public List<Line> getLines() {
            return lines;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        @XmlRootElement(name = "Line")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Line {

            @XmlElement(name = "Line-Item")
            private List<LineItem> lineItems;

            public List<LineItem> getLineItems() {
                return lineItems;
            }

            public void setLineItems(List<LineItem> lineItems) {
                this.lineItems = lineItems;
            }

            @XmlRootElement(name = "LineItem")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineItem {
                @XmlElement(name = "LineNumber")
                private String lineNumber;
                @XmlElement(name = "EAN")
                private String eAN;
                @XmlElement(name = "BuyerItemCode")
                private String buyerItemCode;
                @XmlElement(name = "OrderedQuantity")
                private String orderedQuantity;
                @XmlElement(name = "AcceptedQuantity")
                private String acceptedQuantity;
                @XmlElement(name = "UnitOfMeasure")
                private String unitOfMeasure;
                @XmlElement(name = "UnitNetPrice")
                private String unitNetPrice;
                @XmlElement(name = "UnitGrossPrice")
                private String unitGrossPrice;
                @XmlElement(name = "TaxRate")
                private String taxRate;
                @XmlElement(name = "TaxAmount")
                private String taxAmount;
                @XmlElement(name = "NetAmount")
                private String netAmount;
                @XmlElement(name = "GrossAmount")
                private String grossAmount;

                public String getLineNumber() {
                    return lineNumber;
                }

                public void setLineNumber(String lineNumber) {
                    this.lineNumber = lineNumber;
                }

                public String geteAN() {
                    return eAN;
                }

                public void seteAN(String eAN) {
                    this.eAN = eAN;
                }

                public String getBuyerItemCode() {
                    return buyerItemCode;
                }

                public void setBuyerItemCode(String buyerItemCode) {
                    this.buyerItemCode = buyerItemCode;
                }

                public String getOrderedQuantity() {
                    return orderedQuantity;
                }

                public void setOrderedQuantity(String orderedQuantity) {
                    this.orderedQuantity = orderedQuantity;
                }

                public String getAcceptedQuantity() {
                    return acceptedQuantity;
                }

                public void setAcceptedQuantity(String acceptedQuantity) {
                    this.acceptedQuantity = acceptedQuantity;
                }

                public String getUnitOfMeasure() {
                    return unitOfMeasure;
                }

                public void setUnitOfMeasure(String unitOfMeasure) {
                    this.unitOfMeasure = unitOfMeasure;
                }

                public String getUnitNetPrice() {
                    return unitNetPrice;
                }

                public void setUnitNetPrice(String unitNetPrice) {
                    this.unitNetPrice = unitNetPrice;
                }

                public String getUnitGrossPrice() {
                    return unitGrossPrice;
                }

                public void setUnitGrossPrice(String unitGrossPrice) {
                    this.unitGrossPrice = unitGrossPrice;
                }

                public String getTaxRate() {
                    return taxRate;
                }

                public void setTaxRate(String taxRate) {
                    this.taxRate = taxRate;
                }

                public String getTaxAmount() {
                    return taxAmount;
                }

                public void setTaxAmount(String taxAmount) {
                    this.taxAmount = taxAmount;
                }

                public String getNetAmount() {
                    return netAmount;
                }

                public void setNetAmount(String netAmount) {
                    this.netAmount = netAmount;
                }

                public String getGrossAmount() {
                    return grossAmount;
                }

                public void setGrossAmount(String grossAmount) {
                    this.grossAmount = grossAmount;
                }
            }

        }


    }

    @XmlRootElement(name = "ReceivingAdvice-Summary")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceSummary {
        @XmlElement(name = "TotalLines")
        private String totalLines;

        public String getTotalLines() {
            return totalLines;
        }

        public void setTotalLines(String totalLines) {
            this.totalLines = totalLines;
        }
    }

}
