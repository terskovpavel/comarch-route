package ru.dreamteam.model.ftp.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * Created by kiv1n on 03-Dec-16.
 */
@XmlRootElement(name = "Document-OrderResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class OrdRes {

    @XmlElement(name = "OrderResponse-Header")
    private OrderResponseHeader orderResponseHeader;
    @XmlElement(name = "OrderResponse-Parties")
    private OrderResponseParties orderResponseParties;
    @XmlElement(name = "OrderResponse-Lines")
    private OrderResponseLines orderResponseLines;
    @XmlElement(name = "OrderResponse-Summary")
    private OrderResponseSummary orderResponseSummary;

    public OrderResponseHeader getOrderResponseHeader() {
        return orderResponseHeader;
    }

    public void setOrderResponseHeader(OrderResponseHeader orderResponseHeader) {
        this.orderResponseHeader = orderResponseHeader;
    }

    public OrderResponseParties getOrderResponseParties() {
        return orderResponseParties;
    }

    public void setOrderResponseParties(OrderResponseParties orderResponseParties) {
        this.orderResponseParties = orderResponseParties;
    }

    public OrderResponseLines getOrderResponseLines() {
        return orderResponseLines;
    }

    public void setOrderResponseLines(OrderResponseLines orderResponseLines) {
        this.orderResponseLines = orderResponseLines;
    }

    public OrderResponseSummary getOrderResponseSummary() {
        return orderResponseSummary;
    }

    public void setOrderResponseSummary(OrderResponseSummary orderResponseSummary) {
        this.orderResponseSummary = orderResponseSummary;
    }

    @XmlRootElement(name = "OrderResponse-Header")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderResponseHeader {

        @XmlElement(name = "OrderResponseNumber")
        private String orderResponseNumber;
        @XmlElement(name = "OrderResponseDate")
        private String orderResponseDate;
        @XmlElement(name = "ExpectedDeliveryDate")
        private String expectedDeliveryDate;
        @XmlElement(name = "ExpectedDeliveryTime")
        private String expectedDeliveryTime;
        @XmlElement(name = "DespatchDate")
        private String despatchDate;
        @XmlElement(name = "OrderNumber")
        private String orderNumber;
        @XmlElement(name = "OrderDate")
        private String orderDate;
        @XmlElement(name = "DeliveryNoteNumber")
        private String deliveryNoteNumber;
        @XmlElement(name = "ResponseType")
        private String responseType;

        public String getOrderResponseNumber() {
            return orderResponseNumber;
        }

        public void setOrderResponseNumber(String orderResponseNumber) {
            this.orderResponseNumber = orderResponseNumber;
        }

        public String getOrderResponseDate() {
            return orderResponseDate;
        }

        public void setOrderResponseDate(String orderResponseDate) {
            this.orderResponseDate = orderResponseDate;
        }

        public String getExpectedDeliveryDate() {
            return expectedDeliveryDate;
        }

        public void setExpectedDeliveryDate(String expectedDeliveryDate) {
            this.expectedDeliveryDate = expectedDeliveryDate;
        }

        public String getExpectedDeliveryTime() {
            return expectedDeliveryTime;
        }

        public void setExpectedDeliveryTime(String expectedDeliveryTime) {
            this.expectedDeliveryTime = expectedDeliveryTime;
        }

        public String getDespatchDate() {
            return despatchDate;
        }

        public void setDespatchDate(String despatchDate) {
            this.despatchDate = despatchDate;
        }

        public String getOrderNumber() {
            return orderNumber;
        }

        public void setOrderNumber(String orderNumber) {
            this.orderNumber = orderNumber;
        }

        public String getOrderDate() {
            return orderDate;
        }

        public void setOrderDate(String orderDate) {
            this.orderDate = orderDate;
        }

        public String getDeliveryNoteNumber() {
            return deliveryNoteNumber;
        }

        public void setDeliveryNoteNumber(String deliveryNoteNumber) {
            this.deliveryNoteNumber = deliveryNoteNumber;
        }

        public String getResponseType() {
            return responseType;
        }

        public void setResponseType(String responseType) {
            this.responseType = responseType;
        }
    }

    @XmlRootElement(name = "OrderResponse-Parties")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderResponseParties {

        @XmlElement(name = "Buyer")
        private Buyer buyer;
        @XmlElement(name = "Seller")
        private Seller seller;
        @XmlElement(name = "DeliveryPoint")
        private DeliveryPoint deliveryPoint;
        @XmlElement(name = "UltimateCustomer")
        private UltimateCustomer ultimateCustomer;
        @XmlElement(name = "OrderRecipient")
        private OrderRecipient orderRecipient;

        public Buyer getBuyer() {
            return buyer;
        }

        public void setBuyer(Buyer buyer) {
            this.buyer = buyer;
        }

        public Seller getSeller() {
            return seller;
        }

        public void setSeller(Seller seller) {
            this.seller = seller;
        }

        public DeliveryPoint getDeliveryPoint() {
            return deliveryPoint;
        }

        public void setDeliveryPoint(DeliveryPoint deliveryPoint) {
            this.deliveryPoint = deliveryPoint;
        }

        public UltimateCustomer getUltimateCustomer() {
            return ultimateCustomer;
        }

        public void setUltimateCustomer(UltimateCustomer ultimateCustomer) {
            this.ultimateCustomer = ultimateCustomer;
        }

        public OrderRecipient getOrderRecipient() {
            return orderRecipient;
        }

        public void setOrderRecipient(OrderRecipient orderRecipient) {
            this.orderRecipient = orderRecipient;
        }

        @XmlRootElement(name = "Buyer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Buyer {
            @XmlElement(name = "ILN")
            private String iLN;

            public String getiLN() {
                return iLN;
            }

            public void setiLN(String iLN) {
                this.iLN = iLN;
            }
        }

        @XmlRootElement(name = "Seller")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Seller {
            @XmlElement(name = "ILN")
            private String iLN;

            public String getiLN() {
                return iLN;
            }

            public void setiLN(String iLN) {
                this.iLN = iLN;
            }
        }

        @XmlRootElement(name = "DeliveryPoint")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryPoint {
            @XmlElement(name = "ILN")
            private String iLN;

            public String getiLN() {
                return iLN;
            }

            public void setiLN(String iLN) {
                this.iLN = iLN;
            }
        }

        @XmlRootElement(name = "UltimateCustomer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class UltimateCustomer {
            @XmlElement(name = "ILN")
            private String iLN;

            public String getiLN() {
                return iLN;
            }

            public void setiLN(String iLN) {
                this.iLN = iLN;
            }
        }

        @XmlRootElement(name = "OrderRecipient")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class OrderRecipient {
            @XmlElement(name = "ILN")
            private String iLN;

            public String getiLN() {
                return iLN;
            }

            public void setiLN(String iLN) {
                this.iLN = iLN;
            }
        }

    }

    @XmlRootElement(name = "OrderResponse-Lines")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderResponseLines {

        @XmlElement(name = "Line")
        private List<Line> lines;

        public List<Line> getLines() {
            return lines;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        @XmlRootElement(name = "Line")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Line {

            @XmlElement(name = "Line-Item")
            private List<LineItem> lineItems;

            public List<LineItem> getLineItems() {
                return lineItems;
            }

            public void setLineItems(List<LineItem> lineItems) {
                this.lineItems = lineItems;
            }

            @XmlRootElement(name = "Line-Item")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineItem {

                @XmlElement(name = "LineNumber")
                private String lineNumber;
                @XmlElement(name = "EAN")
                private String eAN;
                @XmlElement(name = "LineItemStatus")
                private String lineItemStatus;
                @XmlElement(name = "BuyerItemCode")
                private String buyerItemCode;
                @XmlElement(name = "ItemDescription")
                private String itemDescription;
                @XmlElement(name = "OrderedQuantity")
                private String orderedQuantity;
                @XmlElement(name = "QuantityToBeDelivered")
                private String quantityToBeDelivered;
                @XmlElement(name = "UnitOfMeasure")
                private String unitOfMeasure;
                @XmlElement(name = "Currency")
                private String currency;
                @XmlElement(name = "OrderedUnitNetPrice")
                private String orderedUnitNetPrice;
                @XmlElement(name = "NetAmount")
                private String netAmount;

                public String getLineNumber() {
                    return lineNumber;
                }

                public void setLineNumber(String lineNumber) {
                    this.lineNumber = lineNumber;
                }

                public String geteAN() {
                    return eAN;
                }

                public void seteAN(String eAN) {
                    this.eAN = eAN;
                }

                public String getLineItemStatus() {
                    return lineItemStatus;
                }

                public void setLineItemStatus(String lineItemStatus) {
                    this.lineItemStatus = lineItemStatus;
                }

                public String getBuyerItemCode() {
                    return buyerItemCode;
                }

                public void setBuyerItemCode(String buyerItemCode) {
                    this.buyerItemCode = buyerItemCode;
                }

                public String getItemDescription() {
                    return itemDescription;
                }

                public void setItemDescription(String itemDescription) {
                    this.itemDescription = itemDescription;
                }

                public String getOrderedQuantity() {
                    return orderedQuantity;
                }

                public void setOrderedQuantity(String orderedQuantity) {
                    this.orderedQuantity = orderedQuantity;
                }

                public String getQuantityToBeDelivered() {
                    return quantityToBeDelivered;
                }

                public void setQuantityToBeDelivered(String quantityToBeDelivered) {
                    this.quantityToBeDelivered = quantityToBeDelivered;
                }

                public String getUnitOfMeasure() {
                    return unitOfMeasure;
                }

                public void setUnitOfMeasure(String unitOfMeasure) {
                    this.unitOfMeasure = unitOfMeasure;
                }

                public String getCurrency() {
                    return currency;
                }

                public void setCurrency(String currency) {
                    this.currency = currency;
                }

                public String getOrderedUnitNetPrice() {
                    return orderedUnitNetPrice;
                }

                public void setOrderedUnitNetPrice(String orderedUnitNetPrice) {
                    this.orderedUnitNetPrice = orderedUnitNetPrice;
                }

                public String getNetAmount() {
                    return netAmount;
                }

                public void setNetAmount(String netAmount) {
                    this.netAmount = netAmount;
                }
            }

        }

    }

    @XmlRootElement(name = "OrderResponse-Summary")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderResponseSummary {

        @XmlElement(name = "TotalLines")
        private String totalLines;

        public String getTotalLines() {
            return totalLines;
        }

        public void setTotalLines(String totalLines) {
            this.totalLines = totalLines;
        }
    }

}
