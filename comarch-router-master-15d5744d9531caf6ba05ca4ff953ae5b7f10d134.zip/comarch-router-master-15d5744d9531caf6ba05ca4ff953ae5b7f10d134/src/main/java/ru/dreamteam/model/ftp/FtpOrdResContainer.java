package ru.dreamteam.model.ftp;

import ru.dreamteam.model.ftp.xml.OrdRes;

public class FtpOrdResContainer {

    private OrdRes ordRes;
    private FTPInfo ftpInfo;

    public FtpOrdResContainer() {
    }

    public FtpOrdResContainer(OrdRes ordRes, FTPInfo ftpInfo) {
        this.ordRes = ordRes;
        this.ftpInfo = ftpInfo;
    }

    public FTPInfo getFtpInfo() {
        return ftpInfo;
    }

    public void setFtpInfo(FTPInfo ftpInfo) {
        this.ftpInfo = ftpInfo;
    }

    public OrdRes getOrdRes() {
        return ordRes;
    }

    public void setOrdRes(OrdRes ordRes) {
        this.ordRes = ordRes;
    }
}
