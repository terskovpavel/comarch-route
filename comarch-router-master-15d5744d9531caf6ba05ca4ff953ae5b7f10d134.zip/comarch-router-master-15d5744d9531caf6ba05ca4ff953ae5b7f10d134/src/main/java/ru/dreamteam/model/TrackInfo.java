package ru.dreamteam.model;

import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "track_info")
public class TrackInfo {

    private String id;
    private DocType docType;
    private Date date;
    private String docNumber;
    private String glnReceiver;
    private String trackingId;
    private String originalXml;
    private String replacedXml;
    private boolean successful;

    public TrackInfo() {
    }

    public TrackInfo(DocType docType, Date date, String docNumber, String glnReceiver, String trackingId) {
        this.docType = docType;
        this.date = date;
        this.docNumber = docNumber;
        this.glnReceiver = glnReceiver;
        this.trackingId = trackingId;
    }

    public TrackInfo(DocType docType, Date date, String docNumber,
                     String glnReceiver, String trackingId, String originalXml,
                     String replacedXml, boolean successful) {
        this.docType = docType;
        this.date = date;
        this.docNumber = docNumber;
        this.glnReceiver = glnReceiver;
        this.trackingId = trackingId;
        this.originalXml = originalXml;
        this.replacedXml = replacedXml;
        this.successful = successful;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DocType getDocType() {
        return docType;
    }

    public void setDocType(DocType docType) {
        this.docType = docType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getGlnReceiver() {
        return glnReceiver;
    }

    public void setGlnReceiver(String glnReceiver) {
        this.glnReceiver = glnReceiver;
    }

    public String getOriginalXml() {
        return originalXml;
    }

    public void setOriginalXml(String originalXml) {
        this.originalXml = originalXml;
    }

    public String getReplacedXml() {
        return replacedXml;
    }

    public void setReplacedXml(String replacedXml) {
        this.replacedXml = replacedXml;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    @Override
    public String toString() {
        return "TrackInfo{" +
                "id='" + id + '\'' +
                ", docType=" + docType +
                ", date=" + date +
                ", docNumber='" + docNumber + '\'' +
                ", glnReceiver='" + glnReceiver + '\'' +
                ", trackingId='" + trackingId + '\'' +
                '}';
    }

    public enum DocType {
        ORDERS, ORDERP, DECADV_IN, RECADV_IN, DECADV_OUT, RECADV_OUT
    }
}
