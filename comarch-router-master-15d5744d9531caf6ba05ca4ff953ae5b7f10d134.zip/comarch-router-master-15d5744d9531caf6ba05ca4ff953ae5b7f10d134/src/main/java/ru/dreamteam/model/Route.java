package ru.dreamteam.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "route")
public class Route {

    private String id;
    private String sender;
    private String deliveryPoint;
    private String routingSender;
    private String receiver;
    private String orgRouteId;

    public Route() {
    }

    public Route(String sender, String deliveryPoint, String receiver, String orgRouteId, String routingSender) {
        this.sender = sender;
        this.deliveryPoint = deliveryPoint;
        this.receiver = receiver;
        this.orgRouteId = orgRouteId;
        this.routingSender = routingSender;
    }

    public String getRoutingSender() {
        return routingSender;
    }

    public void setRoutingSender(String routingSender) {
        this.routingSender = routingSender;
    }

    public String getOrgRouteId() {
        return orgRouteId;
    }

    public void setOrgRouteId(String orgRouteId) {
        this.orgRouteId = orgRouteId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getDeliveryPoint() {
        return deliveryPoint;
    }

    public void setDeliveryPoint(String deliveryPoint) {
        this.deliveryPoint = deliveryPoint;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    @Override
    public String toString() {
        return "Route{" +
                "id='" + id + '\'' +
                ", sender='" + sender + '\'' +
                ", deliveryPoint='" + deliveryPoint + '\'' +
                ", receiver='" + receiver + '\'' +
                ", orgRouteId='" + orgRouteId + '\'' +
                '}';
    }
}
