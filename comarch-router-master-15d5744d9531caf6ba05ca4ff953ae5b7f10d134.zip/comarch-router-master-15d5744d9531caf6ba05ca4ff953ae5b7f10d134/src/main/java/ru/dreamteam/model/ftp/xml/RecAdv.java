package ru.dreamteam.model.ftp.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "Document-ReceivingAdvice")
@XmlAccessorType(XmlAccessType.FIELD)
public class RecAdv {

    @XmlElement(name = "ReceivingAdvice-Header")
    private ReceivingAdviceHeader receivingAdviceHeader;
    @XmlElement(name = "ReceivingAdvice-Reference")
    private ReceivingAdviceReference receivingAdviceReference;
    @XmlElement(name = "ReceivingAdvice-Parties")
    private ReceivingAdviceParties receivingAdviceParties;
    @XmlElement(name = "ReceivingAdvice-Lines")
    private ReceivingAdviceLines receivingAdviceLines;
    @XmlElement(name = "ReceivingAdvice-Summary")
    private ReceivingAdviceSummary receivingAdviceSummary;

    public ReceivingAdviceHeader getReceivingAdviceHeader() {
        return receivingAdviceHeader;
    }

    public void setReceivingAdviceHeader(ReceivingAdviceHeader receivingAdviceHeader) {
        this.receivingAdviceHeader = receivingAdviceHeader;
    }

    public ReceivingAdviceReference getReceivingAdviceReference() {
        return receivingAdviceReference;
    }

    public void setReceivingAdviceReference(ReceivingAdviceReference receivingAdviceReference) {
        this.receivingAdviceReference = receivingAdviceReference;
    }

    public ReceivingAdviceParties getReceivingAdviceParties() {
        return receivingAdviceParties;
    }

    public void setReceivingAdviceParties(ReceivingAdviceParties receivingAdviceParties) {
        this.receivingAdviceParties = receivingAdviceParties;
    }

    public ReceivingAdviceLines getReceivingAdviceLines() {
        return receivingAdviceLines;
    }

    public void setReceivingAdviceLines(ReceivingAdviceLines receivingAdviceLines) {
        this.receivingAdviceLines = receivingAdviceLines;
    }

    public ReceivingAdviceSummary getReceivingAdviceSummary() {
        return receivingAdviceSummary;
    }

    public void setReceivingAdviceSummary(ReceivingAdviceSummary receivingAdviceSummary) {
        this.receivingAdviceSummary = receivingAdviceSummary;
    }

    @XmlRootElement(name = "ReceivingAdvice-Header")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceHeader {

        @XmlElement(name = "ReceivingAdviceNumber")
        private String ReceivingAdviceNumber;
        @XmlElement(name = "ReceivingAdviceDate")
        private String ReceivingAdviceDate;
        @XmlElement(name = "ReceivingAdviceTime")
        private String ReceivingAdviceTime;
        @XmlElement(name = "GoodsReceiptDate")
        private String GoodsReceiptDate;
        @XmlElement(name = "DocumentFunctionCode")
        private String DocumentFunctionCode;

        public String getReceivingAdviceNumber() {
            return ReceivingAdviceNumber;
        }

        public void setReceivingAdviceNumber(String receivingAdviceNumber) {
            ReceivingAdviceNumber = receivingAdviceNumber;
        }

        public String getReceivingAdviceDate() {
            return ReceivingAdviceDate;
        }

        public void setReceivingAdviceDate(String receivingAdviceDate) {
            ReceivingAdviceDate = receivingAdviceDate;
        }

        public String getReceivingAdviceTime() {
            return ReceivingAdviceTime;
        }

        public void setReceivingAdviceTime(String receivingAdviceTime) {
            ReceivingAdviceTime = receivingAdviceTime;
        }

        public String getGoodsReceiptDate() {
            return GoodsReceiptDate;
        }

        public void setGoodsReceiptDate(String goodsReceiptDate) {
            GoodsReceiptDate = goodsReceiptDate;
        }

        public String getDocumentFunctionCode() {
            return DocumentFunctionCode;
        }

        public void setDocumentFunctionCode(String documentFunctionCode) {
            DocumentFunctionCode = documentFunctionCode;
        }
    }

    @XmlRootElement(name = "ReceivingAdvice-Reference")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceReference {

        @XmlElement(name = "Order")
        private Order order;
        @XmlElement(name = "DeliveryNote")
        private DeliveryNote deliveryNote;
        @XmlElement(name = "InternalDocument")
        private InternalDocument internalDocument;

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        public DeliveryNote getDeliveryNote() {
            return deliveryNote;
        }

        public void setDeliveryNote(DeliveryNote deliveryNote) {
            this.deliveryNote = deliveryNote;
        }

        public InternalDocument getInternalDocument() {
            return internalDocument;
        }

        public void setInternalDocument(InternalDocument internalDocument) {
            this.internalDocument = internalDocument;
        }

        @XmlRootElement(name = "Order")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Order {
            @XmlElement(name = "BuyerOrderNumber")
            private String buyerOrderNumber;
            @XmlElement(name = "BuyerOrderDate")
            private String buyerOrderDate;

            public String getBuyerOrderNumber() {
                return buyerOrderNumber;
            }

            public void setBuyerOrderNumber(String buyerOrderNumber) {
                this.buyerOrderNumber = buyerOrderNumber;
            }

            public String getBuyerOrderDate() {
                return buyerOrderDate;
            }

            public void setBuyerOrderDate(String buyerOrderDate) {
                this.buyerOrderDate = buyerOrderDate;
            }
        }

        @XmlRootElement(name = "DeliveryNote")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryNote {
            @XmlElement(name = "DeliveryNoteNumber")
            private String deliveryNoteNumber;

            public String getDeliveryNoteNumber() {
                return deliveryNoteNumber;
            }

            public void setDeliveryNoteNumber(String deliveryNoteNumber) {
                this.deliveryNoteNumber = deliveryNoteNumber;
            }
        }

        @XmlRootElement(name = "InternalDocument")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class InternalDocument {
            @XmlElement(name = "InternalDocumentNumber")
            private String internalDocumentNumber;

            public String getInternalDocumentNumber() {
                return internalDocumentNumber;
            }

            public void setInternalDocumentNumber(String internalDocumentNumber) {
                this.internalDocumentNumber = internalDocumentNumber;
            }
        }

    }

    @XmlRootElement(name = "ReceivingAdvice-Parties")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceParties {

        @XmlElement(name = "Buyer")
        private Buyer buyer;
        @XmlElement(name = "Seller")
        private Seller seller;
        @XmlElement(name = "DeliveryPoint")
        private DeliveryPoint deliveryPoint;
        @XmlElement(name = "OrderRecipient")
        private OrderRecipient orderRecipient;
        @XmlElement(name = "Payer")
        private Payer payer;

        public Buyer getBuyer() {
            return buyer;
        }

        public void setBuyer(Buyer buyer) {
            this.buyer = buyer;
        }

        public Seller getSeller() {
            return seller;
        }

        public void setSeller(Seller seller) {
            this.seller = seller;
        }

        public DeliveryPoint getDeliveryPoint() {
            return deliveryPoint;
        }

        public void setDeliveryPoint(DeliveryPoint deliveryPoint) {
            this.deliveryPoint = deliveryPoint;
        }

        public OrderRecipient getOrderRecipient() {
            return orderRecipient;
        }

        public void setOrderRecipient(OrderRecipient orderRecipient) {
            this.orderRecipient = orderRecipient;
        }

        public Payer getPayer() {
            return payer;
        }

        public void setPayer(Payer payer) {
            this.payer = payer;
        }

        @XmlRootElement(name = "Buyer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Buyer {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "Seller")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Seller {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "DeliveryPoint")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryPoint {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "OrderRecipient")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class OrderRecipient {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "Payer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Payer {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

    }

    @XmlRootElement(name = "ReceivingAdvice-Lines")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceLines {

        @XmlElement(name = "Line")
        private List<Line> lines;

        public List<Line> getLines() {
            return lines;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        @XmlRootElement(name = "Line")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Line {

            @XmlElement(name = "Line-Item")
            private List<LineItem> lineItems;

            public List<LineItem> getLineItems() {
                return lineItems;
            }

            public void setLineItems(List<LineItem> lineItems) {
                this.lineItems = lineItems;
            }

            @XmlRootElement(name = "LineItem")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineItem {
                @XmlElement(name = "LineNumber")
                private String lineNumber;
                @XmlElement(name = "EAN")
                private String eAN;
                @XmlElement(name = "BuyerItemCode")
                private String buyerItemCode;
                @XmlElement(name = "OrderedQuantity")
                private String orderedQuantity;
                @XmlElement(name = "AcceptedQuantity")
                private String acceptedQuantity;
                @XmlElement(name = "UnitOfMeasure")
                private String unitOfMeasure;
                @XmlElement(name = "UnitNetPrice")
                private String unitNetPrice;
                @XmlElement(name = "UnitGrossPrice")
                private String unitGrossPrice;

                public String getLineNumber() {
                    return lineNumber;
                }

                public void setLineNumber(String lineNumber) {
                    this.lineNumber = lineNumber;
                }

                public String geteAN() {
                    return eAN;
                }

                public void seteAN(String eAN) {
                    this.eAN = eAN;
                }

                public String getBuyerItemCode() {
                    return buyerItemCode;
                }

                public void setBuyerItemCode(String buyerItemCode) {
                    this.buyerItemCode = buyerItemCode;
                }

                public String getOrderedQuantity() {
                    return orderedQuantity;
                }

                public void setOrderedQuantity(String orderedQuantity) {
                    this.orderedQuantity = orderedQuantity;
                }

                public String getAcceptedQuantity() {
                    return acceptedQuantity;
                }

                public void setAcceptedQuantity(String acceptedQuantity) {
                    this.acceptedQuantity = acceptedQuantity;
                }

                public String getUnitOfMeasure() {
                    return unitOfMeasure;
                }

                public void setUnitOfMeasure(String unitOfMeasure) {
                    this.unitOfMeasure = unitOfMeasure;
                }

                public String getUnitNetPrice() {
                    return unitNetPrice;
                }

                public void setUnitNetPrice(String unitNetPrice) {
                    this.unitNetPrice = unitNetPrice;
                }

                public String getUnitGrossPrice() {
                    return unitGrossPrice;
                }

                public void setUnitGrossPrice(String unitGrossPrice) {
                    this.unitGrossPrice = unitGrossPrice;
                }
            }

        }


    }

    @XmlRootElement(name = "ReceivingAdvice-Summary")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ReceivingAdviceSummary {
        @XmlElement(name = "TotalLines")
        private String totalLines;

        public String getTotalLines() {
            return totalLines;
        }

        public void setTotalLines(String totalLines) {
            this.totalLines = totalLines;
        }
    }




}