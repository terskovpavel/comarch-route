package ru.dreamteam.model.ftp;

public class FTPInfo {

    private String fileName;
    private String fileContent;

    public FTPInfo() {
    }

    public FTPInfo(String fileName, String fileContent) {
        this.fileName = fileName;
        this.fileContent = fileContent;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileContent() {
        return fileContent;
    }

    public void setFileContent(String fileContent) {
        this.fileContent = fileContent;
    }
}
