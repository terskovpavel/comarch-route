package ru.dreamteam.model.soap.receive;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "Document-Order")
@XmlAccessorType(XmlAccessType.FIELD)
public class DocumentOrder {

    @XmlElement(name = "Order-Header")
    private OrderHeader orderHeader;
    @XmlElement(name = "Order-Parties")
    private OrderParties orderParties;
    @XmlElement(name = "Order-Lines")
    private OrderLines orderLines;
    @XmlElement(name = "Order-Summary")
    private OrderSummary orderSummary;

    public OrderHeader getOrderHeader() {
        return orderHeader;
    }

    public void setOrderHeader(OrderHeader orderHeader) {
        this.orderHeader = orderHeader;
    }

    public OrderParties getOrderParties() {
        return orderParties;
    }

    public void setOrderParties(OrderParties orderParties) {
        this.orderParties = orderParties;
    }

    public OrderLines getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(OrderLines orderLines) {
        this.orderLines = orderLines;
    }

    public OrderSummary getOrderSummary() {
        return orderSummary;
    }

    public void setOrderSummary(OrderSummary orderSummary) {
        this.orderSummary = orderSummary;
    }

    @XmlRootElement(name = "Order-Header")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderHeader {

        @XmlElement(name = "OrderNumber")
        private String orderNumber;
        @XmlElement(name = "OrderDate")
        private String orderDate;
        @XmlElement(name = "ExpectedDeliveryDate")
        private String expectedDeliveryDate;
        @XmlElement(name = "DocumentFunctionCode")
        private String documentFunctionCode;

        public String getOrderNumber() {
            return orderNumber;
        }

        public void setOrderNumber(String orderNumber) {
            this.orderNumber = orderNumber;
        }

        public String getOrderDate() {
            return orderDate;
        }

        public void setOrderDate(String orderDate) {
            this.orderDate = orderDate;
        }

        public String getExpectedDeliveryDate() {
            return expectedDeliveryDate;
        }

        public void setExpectedDeliveryDate(String expectedDeliveryDate) {
            this.expectedDeliveryDate = expectedDeliveryDate;
        }

        public String getDocumentFunctionCode() {
            return documentFunctionCode;
        }

        public void setDocumentFunctionCode(String documentFunctionCode) {
            this.documentFunctionCode = documentFunctionCode;
        }
    }

    @XmlRootElement(name = "Order-Parties")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderParties {

        @XmlElement(name = "Buyer")
        private Buyer buyer;
        @XmlElement(name = "Seller")
        private Seller seller;
        @XmlElement(name = "DeliveryPoint")
        private DeliveryPoint deliveryPoint;
        @XmlElement(name = "Invoicee")
        private Invoicee invoicee;

        public Buyer getBuyer() {
            return buyer;
        }

        public void setBuyer(Buyer buyer) {
            this.buyer = buyer;
        }

        public Seller getSeller() {
            return seller;
        }

        public void setSeller(Seller seller) {
            this.seller = seller;
        }

        public DeliveryPoint getDeliveryPoint() {
            return deliveryPoint;
        }

        public void setDeliveryPoint(DeliveryPoint deliveryPoint) {
            this.deliveryPoint = deliveryPoint;
        }

        public Invoicee getInvoicee() {
            return invoicee;
        }

        public void setInvoicee(Invoicee invoicee) {
            this.invoicee = invoicee;
        }

        @XmlRootElement(name = "Buyer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Buyer {
            @XmlElement(name = "ILN")
            String iln;

            public String getIln() {
                return iln;
            }

            public void setIln(String iln) {
                this.iln = iln;
            }
        }

        @XmlRootElement(name = "Seller")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Seller {
            @XmlElement(name = "ILN")
            String iln;

            public String getIln() {
                return iln;
            }

            public void setIln(String iln) {
                this.iln = iln;
            }
        }

        @XmlRootElement(name = "DeliveryPoint")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryPoint {
            @XmlElement(name = "ILN")
            String iln;

            public String getIln() {
                return iln;
            }

            public void setIln(String iln) {
                this.iln = iln;
            }
        }

        @XmlRootElement(name = "Invoicee")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Invoicee {
            @XmlElement(name = "ILN")
            String iln;

            public String getIln() {
                return iln;
            }

            public void setIln(String iln) {
                this.iln = iln;
            }
        }

    }

    @XmlRootElement(name = "Order-Lines")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderLines {

        @XmlElement(name = "Line")
        private List<Line> lines;

        public List<Line> getLines() {
            return lines;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        @XmlRootElement(name = "Line")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Line {

            @XmlElement(name = "Line-Item")
            private List<LineItem> lineItems;

            @XmlRootElement(name = "Line-Item")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineItem {

                @XmlElement(name = "LineNumber")
                private String lineNumber;
                @XmlElement(name = "EAN")
                private String EAN;
                @XmlElement(name = "BuyerItemCode")
                private String buyerItemCode;
                @XmlElement(name = "SupplierItemCode")
                private String supplierItemCode;
                @XmlElement(name = "ItemDescription")
                private String itemDescription;
                @XmlElement(name = "ItemType")
                private String itemType;
                @XmlElement(name = "OrderedQuantity")
                private String orderedQuantity;
                @XmlElement(name = "OrderedUnitNetPrice")
                private String orderedUnitNetPrice;

                public String getLineNumber() {
                    return lineNumber;
                }

                public void setLineNumber(String lineNumber) {
                    this.lineNumber = lineNumber;
                }

                public String getEAN() {
                    return EAN;
                }

                public void setEAN(String EAN) {
                    this.EAN = EAN;
                }

                public String getBuyerItemCode() {
                    return buyerItemCode;
                }

                public void setBuyerItemCode(String buyerItemCode) {
                    this.buyerItemCode = buyerItemCode;
                }

                public String getSupplierItemCode() {
                    return supplierItemCode;
                }

                public void setSupplierItemCode(String supplierItemCode) {
                    this.supplierItemCode = supplierItemCode;
                }

                public String getItemDescription() {
                    return itemDescription;
                }

                public void setItemDescription(String itemDescription) {
                    this.itemDescription = itemDescription;
                }

                public String getItemType() {
                    return itemType;
                }

                public void setItemType(String itemType) {
                    this.itemType = itemType;
                }

                public String getOrderedQuantity() {
                    return orderedQuantity;
                }

                public void setOrderedQuantity(String orderedQuantity) {
                    this.orderedQuantity = orderedQuantity;
                }

                public String getOrderedUnitNetPrice() {
                    return orderedUnitNetPrice;
                }

                public void setOrderedUnitNetPrice(String orderedUnitNetPrice) {
                    this.orderedUnitNetPrice = orderedUnitNetPrice;
                }
            }

        }

    }

    @XmlRootElement(name = "Order-Summary")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class OrderSummary {

        @XmlElement(name = "TotalLines")
        private String totalLines;
        @XmlElement(name = "TotalOrderedAmount")
        private String totalOrderedAmount;

        public String getTotalLines() {
            return totalLines;
        }

        public void setTotalLines(String totalLines) {
            this.totalLines = totalLines;
        }
    }

}
