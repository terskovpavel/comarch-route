package ru.dreamteam.model.ftp.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "Document-DespatchAdvice")
@XmlAccessorType(XmlAccessType.FIELD)
public class DesAdv {

    // DespatchAdvice-Header
    @XmlElement(name = "DespatchAdvice-Header")
    private DespatchAdviceHeader despatchAdviceHeader;
    // DespatchAdvice-Parties
    @XmlElement(name = "DespatchAdvice-Parties")
    private DespatchAdviceParties despatchAdviceParties;
    // DespatchAdvice-Lines
    @XmlElement(name = "DespatchAdvice-Lines")
    private DespatchAdviceLines despatchAdviceLines;
    // DespatchAdvice-Summary
    @XmlElement(name = "DespatchAdvice-Summary")
    private DespatchAdviceSummary despatchAdviceSummary;

    public DespatchAdviceHeader getDespatchAdviceHeader() {
        return despatchAdviceHeader;
    }

    public void setDespatchAdviceHeader(DespatchAdviceHeader despatchAdviceHeader) {
        this.despatchAdviceHeader = despatchAdviceHeader;
    }

    public DespatchAdviceParties getDespatchAdviceParties() {
        return despatchAdviceParties;
    }

    public void setDespatchAdviceParties(DespatchAdviceParties despatchAdviceParties) {
        this.despatchAdviceParties = despatchAdviceParties;
    }

    public DespatchAdviceLines getDespatchAdviceLines() {
        return despatchAdviceLines;
    }

    public void setDespatchAdviceLines(DespatchAdviceLines despatchAdviceLines) {
        this.despatchAdviceLines = despatchAdviceLines;
    }

    public DespatchAdviceSummary getDespatchAdviceSummary() {
        return despatchAdviceSummary;
    }

    public void setDespatchAdviceSummary(DespatchAdviceSummary despatchAdviceSummary) {
        this.despatchAdviceSummary = despatchAdviceSummary;
    }

    // DespatchAdvice-Header
    @XmlRootElement(name = "DespatchAdvice-Header")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class DespatchAdviceHeader {

        @XmlElement(name = "DespatchAdviceNumber")
        private String DespatchAdviceNumber;
        @XmlElement(name = "DespatchAdviceDate")
        private String DespatchAdviceDate;
        @XmlElement(name = "DespatchAdviceTime")
        private String DespatchAdviceTime;
        @XmlElement(name = "EstimatedDeliveryDate")
        private String EstimatedDeliveryDate;
        @XmlElement(name = "BuyerOrderNumber")
        private String BuyerOrderNumber;
        @XmlElement(name = "BuyerOrderDate")
        private String BuyerOrderDate;
        @XmlElement(name = "SupplierOrderNumber")
        private String SupplierOrderNumber;
        @XmlElement(name = "SupplierOrderDate")
        private String SupplierOrderDate;
        @XmlElement(name = "DespatchNumber")
        private String DespatchNumber;
        @XmlElement(name = "DespatchDate")
        private String DespatchDate;
        @XmlElement(name = "DeliveryNoteNumber")
        private String DeliveryNoteNumber;
        @XmlElement(name = "InvoiceNumber")
        private String InvoiceNumber;
        @XmlElement(name = "InvoiceDate")
        private String InvoiceDate;
        @XmlElement(name = "ContractNumber")
        private String ContractNumber;
        @XmlElement(name = "DocumentFunctionCode")
        private String DocumentFunctionCode;
        @XmlElement(name = "Currency")
        private String Currency;
        @XmlElement(name = "Order-Measurement")
        private OrderMeasurement orderMeasurement;

        public String getDespatchAdviceNumber() {
            return DespatchAdviceNumber;
        }

        public void setDespatchAdviceNumber(String despatchAdviceNumber) {
            DespatchAdviceNumber = despatchAdviceNumber;
        }

        public String getDespatchAdviceDate() {
            return DespatchAdviceDate;
        }

        public void setDespatchAdviceDate(String despatchAdviceDate) {
            DespatchAdviceDate = despatchAdviceDate;
        }

        public String getDespatchAdviceTime() {
            return DespatchAdviceTime;
        }

        public void setDespatchAdviceTime(String despatchAdviceTime) {
            DespatchAdviceTime = despatchAdviceTime;
        }

        public String getEstimatedDeliveryDate() {
            return EstimatedDeliveryDate;
        }

        public void setEstimatedDeliveryDate(String estimatedDeliveryDate) {
            EstimatedDeliveryDate = estimatedDeliveryDate;
        }

        public String getBuyerOrderNumber() {
            return BuyerOrderNumber;
        }

        public void setBuyerOrderNumber(String buyerOrderNumber) {
            BuyerOrderNumber = buyerOrderNumber;
        }

        public String getBuyerOrderDate() {
            return BuyerOrderDate;
        }

        public void setBuyerOrderDate(String buyerOrderDate) {
            BuyerOrderDate = buyerOrderDate;
        }

        public String getSupplierOrderNumber() {
            return SupplierOrderNumber;
        }

        public void setSupplierOrderNumber(String supplierOrderNumber) {
            SupplierOrderNumber = supplierOrderNumber;
        }

        public String getSupplierOrderDate() {
            return SupplierOrderDate;
        }

        public void setSupplierOrderDate(String supplierOrderDate) {
            SupplierOrderDate = supplierOrderDate;
        }

        public String getDespatchNumber() {
            return DespatchNumber;
        }

        public void setDespatchNumber(String despatchNumber) {
            DespatchNumber = despatchNumber;
        }

        public String getDespatchDate() {
            return DespatchDate;
        }

        public void setDespatchDate(String despatchDate) {
            DespatchDate = despatchDate;
        }

        public String getDeliveryNoteNumber() {
            return DeliveryNoteNumber;
        }

        public void setDeliveryNoteNumber(String deliveryNoteNumber) {
            DeliveryNoteNumber = deliveryNoteNumber;
        }

        public String getInvoiceNumber() {
            return InvoiceNumber;
        }

        public void setInvoiceNumber(String invoiceNumber) {
            InvoiceNumber = invoiceNumber;
        }

        public String getInvoiceDate() {
            return InvoiceDate;
        }

        public void setInvoiceDate(String invoiceDate) {
            InvoiceDate = invoiceDate;
        }

        public String getContractNumber() {
            return ContractNumber;
        }

        public void setContractNumber(String contractNumber) {
            ContractNumber = contractNumber;
        }

        public String getDocumentFunctionCode() {
            return DocumentFunctionCode;
        }

        public void setDocumentFunctionCode(String documentFunctionCode) {
            DocumentFunctionCode = documentFunctionCode;
        }

        public String getCurrency() {
            return Currency;
        }

        public void setCurrency(String currency) {
            Currency = currency;
        }

        public OrderMeasurement getOrderMeasurement() {
            return orderMeasurement;
        }

        public void setOrderMeasurement(OrderMeasurement orderMeasurement) {
            this.orderMeasurement = orderMeasurement;
        }

        // Order-Measurement
        @XmlRootElement(name = "Order-Measurement")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class OrderMeasurement {
            // AdditionalQuantity
            @XmlElement(name = "AdditionalQuantity")
            private String additionalQuantity;
            // AdditionalUnitOfMeasure
            @XmlElement(name = "AdditionalUnitOfMeasure")
            private String additionalUnitOfMeasure;

            public String getAdditionalQuantity() {
                return additionalQuantity;
            }

            public void setAdditionalQuantity(String additionalQuantity) {
                this.additionalQuantity = additionalQuantity;
            }

            public String getAdditionalUnitOfMeasure() {
                return additionalUnitOfMeasure;
            }

            public void setAdditionalUnitOfMeasure(String additionalUnitOfMeasure) {
                this.additionalUnitOfMeasure = additionalUnitOfMeasure;
            }
        }

    }

    // DespatchAdvice-Parties
    @XmlRootElement(name = "DespatchAdvice-Parties")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class DespatchAdviceParties {

        @XmlElement(name = "Buyer")
        private Buyer buyer;
        @XmlElement(name = "Seller")
        private Seller seller;
        @XmlElement(name = "DeliveryPoint")
        private DeliveryPoint deliveryPoint;
        @XmlElement(name = "OrderRecipient")
        private OrderRecipient orderRecipient;
        @XmlElement(name = "Consignor")
        private Consignor consignor;

        public Buyer getBuyer() {
            return buyer;
        }

        public void setBuyer(Buyer buyer) {
            this.buyer = buyer;
        }

        public Seller getSeller() {
            return seller;
        }

        public void setSeller(Seller seller) {
            this.seller = seller;
        }

        public DeliveryPoint getDeliveryPoint() {
            return deliveryPoint;
        }

        public void setDeliveryPoint(DeliveryPoint deliveryPoint) {
            this.deliveryPoint = deliveryPoint;
        }

        public OrderRecipient getOrderRecipient() {
            return orderRecipient;
        }

        public void setOrderRecipient(OrderRecipient orderRecipient) {
            this.orderRecipient = orderRecipient;
        }

        public Consignor getConsignor() {
            return consignor;
        }

        public void setConsignor(Consignor consignor) {
            this.consignor = consignor;
        }

        @XmlRootElement(name = "Buyer")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Buyer {
            @XmlElement(name = "ILN")
            private String ILN;
            @XmlElement(name = "TaxID")
            private String TaxID;
            @XmlElement(name = "AccountNumber")
            private String AccountNumber;
            @XmlElement(name = "FinancialInstitutionName")
            private String FinancialInstitutionName;
            @XmlElement(name = "FinancialInstitutionID")
            private String FinancialInstitutionID;
            @XmlElement(name = "UtilizationRegisterNumber")
            private String UtilizationRegisterNumber;
            @XmlElement(name = "Name")
            private String Name;
            @XmlElement(name = "StreetAndNumber")
            private String StreetAndNumber;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }

            public String getTaxID() {
                return TaxID;
            }

            public void setTaxID(String taxID) {
                TaxID = taxID;
            }

            public String getAccountNumber() {
                return AccountNumber;
            }

            public void setAccountNumber(String accountNumber) {
                AccountNumber = accountNumber;
            }

            public String getFinancialInstitutionName() {
                return FinancialInstitutionName;
            }

            public void setFinancialInstitutionName(String financialInstitutionName) {
                FinancialInstitutionName = financialInstitutionName;
            }

            public String getFinancialInstitutionID() {
                return FinancialInstitutionID;
            }

            public void setFinancialInstitutionID(String financialInstitutionID) {
                FinancialInstitutionID = financialInstitutionID;
            }

            public String getUtilizationRegisterNumber() {
                return UtilizationRegisterNumber;
            }

            public void setUtilizationRegisterNumber(String utilizationRegisterNumber) {
                UtilizationRegisterNumber = utilizationRegisterNumber;
            }

            public String getName() {
                return Name;
            }

            public void setName(String name) {
                Name = name;
            }

            public String getStreetAndNumber() {
                return StreetAndNumber;
            }

            public void setStreetAndNumber(String streetAndNumber) {
                StreetAndNumber = streetAndNumber;
            }
        }

        @XmlRootElement(name = "Seller")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Seller {
            @XmlElement(name = "ILN")
            private String ILN;
            @XmlElement(name = "TaxID")
            private String TaxID;
            @XmlElement(name = "AccountNumber")
            private String AccountNumber;
            @XmlElement(name = "FinancialInstitutionName")
            private String FinancialInstitutionName;
            @XmlElement(name = "UtilizationRegisterNumber")
            private String UtilizationRegisterNumber;
            @XmlElement(name = "Name")
            private String Name;
            @XmlElement(name = "StreetAndNumber")
            private String StreetAndNumber;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }

            public String getTaxID() {
                return TaxID;
            }

            public void setTaxID(String taxID) {
                TaxID = taxID;
            }

            public String getAccountNumber() {
                return AccountNumber;
            }

            public void setAccountNumber(String accountNumber) {
                AccountNumber = accountNumber;
            }

            public String getFinancialInstitutionName() {
                return FinancialInstitutionName;
            }

            public void setFinancialInstitutionName(String financialInstitutionName) {
                FinancialInstitutionName = financialInstitutionName;
            }

            public String getUtilizationRegisterNumber() {
                return UtilizationRegisterNumber;
            }

            public void setUtilizationRegisterNumber(String utilizationRegisterNumber) {
                UtilizationRegisterNumber = utilizationRegisterNumber;
            }

            public String getName() {
                return Name;
            }

            public void setName(String name) {
                Name = name;
            }

            public String getStreetAndNumber() {
                return StreetAndNumber;
            }

            public void setStreetAndNumber(String streetAndNumber) {
                StreetAndNumber = streetAndNumber;
            }
        }

        @XmlRootElement(name = "DeliveryPoint")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class DeliveryPoint {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "OrderRecipient")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class OrderRecipient {
            @XmlElement(name = "ILN")
            private String ILN;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }
        }

        @XmlRootElement(name = "Consignor")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Consignor {
            @XmlElement(name = "ILN")
            private String ILN;
            @XmlElement(name = "TaxID")
            private String TaxID;

            public String getILN() {
                return ILN;
            }

            public void setILN(String ILN) {
                this.ILN = ILN;
            }

            public String getTaxID() {
                return TaxID;
            }

            public void setTaxID(String taxID) {
                TaxID = taxID;
            }
        }
    }

    // DespatchAdvice-Lines
    @XmlRootElement(name = "DespatchAdvice-Lines")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class DespatchAdviceLines {

        @XmlElement(name = "Line")
        private List<Line> lines;

        public List<Line> getLines() {
            return lines;
        }

        public void setLines(List<Line> lines) {
            this.lines = lines;
        }

        @XmlRootElement(name = "Line")
        @XmlAccessorType(XmlAccessType.FIELD)
        public static class Line {

            @XmlElement(name = "Line-Item")
            private List<LineItem> lineItems;

            @XmlElement(name = "Line-Order")
            private LineOrder lineOrder;

            public List<LineItem> getLineItems() {
                return lineItems;
            }

            public void setLineItems(List<LineItem> lineItems) {
                this.lineItems = lineItems;
            }

            public LineOrder getLineOrder() {
                return lineOrder;
            }

            public void setLineOrder(LineOrder lineOrder) {
                this.lineOrder = lineOrder;
            }

            // Line-Item
            @XmlRootElement(name = "Line-Item")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineItem {
                @XmlElement(name = "LineNumber")
                private String LineNumber;
                @XmlElement(name = "OrderLineNumber")
                private String OrderLineNumber;
                @XmlElement(name = "EAN")
                private String EAN;
                @XmlElement(name = "BuyerItemCode")
                private String BuyerItemCode;
                @XmlElement(name = "SupplierItemCode")
                private String SupplierItemCode;
                @XmlElement(name = "DespatchedQuantity")
                private String DespatchedQuantity;
                @XmlElement(name = "OrderedQuantity")
                private String OrderedQuantity;
                @XmlElement(name = "UnitOfMeasure")
                private String UnitOfMeasure;
                @XmlElement(name = "ItemDescription")
                private String ItemDescription;
                @XmlElement(name = "UnitNetPrice")
                private String UnitNetPrice;
                @XmlElement(name = "UnitGrossPrice")
                private String UnitGrossPrice;
                @XmlElement(name = "TaxAmount")
                private String TaxAmount;
                @XmlElement(name = "NetAmount")
                private String NetAmount;
                @XmlElement(name = "GrossAmount")
                private String GrossAmount;
                @XmlElement(name = "OriginalAmount")
                private String OriginalAmount;
                @XmlElement(name = "TaxRate")
                private String TaxRate;
                @XmlElement(name = "CountryOfOriginCode")
                private String CountryOfOriginCode;

                public String getLineNumber() {
                    return LineNumber;
                }

                public void setLineNumber(String lineNumber) {
                    LineNumber = lineNumber;
                }

                public String getOrderLineNumber() {
                    return OrderLineNumber;
                }

                public void setOrderLineNumber(String orderLineNumber) {
                    OrderLineNumber = orderLineNumber;
                }

                public String getEAN() {
                    return EAN;
                }

                public void setEAN(String EAN) {
                    this.EAN = EAN;
                }

                public String getBuyerItemCode() {
                    return BuyerItemCode;
                }

                public void setBuyerItemCode(String buyerItemCode) {
                    BuyerItemCode = buyerItemCode;
                }

                public String getSupplierItemCode() {
                    return SupplierItemCode;
                }

                public void setSupplierItemCode(String supplierItemCode) {
                    SupplierItemCode = supplierItemCode;
                }

                public String getDespatchedQuantity() {
                    return DespatchedQuantity;
                }

                public void setDespatchedQuantity(String despatchedQuantity) {
                    DespatchedQuantity = despatchedQuantity;
                }

                public String getOrderedQuantity() {
                    return OrderedQuantity;
                }

                public void setOrderedQuantity(String orderedQuantity) {
                    OrderedQuantity = orderedQuantity;
                }

                public String getUnitOfMeasure() {
                    return UnitOfMeasure;
                }

                public void setUnitOfMeasure(String unitOfMeasure) {
                    UnitOfMeasure = unitOfMeasure;
                }

                public String getItemDescription() {
                    return ItemDescription;
                }

                public void setItemDescription(String itemDescription) {
                    ItemDescription = itemDescription;
                }

                public String getUnitNetPrice() {
                    return UnitNetPrice;
                }

                public void setUnitNetPrice(String unitNetPrice) {
                    UnitNetPrice = unitNetPrice;
                }

                public String getUnitGrossPrice() {
                    return UnitGrossPrice;
                }

                public void setUnitGrossPrice(String unitGrossPrice) {
                    UnitGrossPrice = unitGrossPrice;
                }

                public String getTaxAmount() {
                    return TaxAmount;
                }

                public void setTaxAmount(String taxAmount) {
                    TaxAmount = taxAmount;
                }

                public String getNetAmount() {
                    return NetAmount;
                }

                public void setNetAmount(String netAmount) {
                    NetAmount = netAmount;
                }

                public String getGrossAmount() {
                    return GrossAmount;
                }

                public void setGrossAmount(String grossAmount) {
                    GrossAmount = grossAmount;
                }

                public String getOriginalAmount() {
                    return OriginalAmount;
                }

                public void setOriginalAmount(String originalAmount) {
                    OriginalAmount = originalAmount;
                }

                public String getTaxRate() {
                    return TaxRate;
                }

                public void setTaxRate(String taxRate) {
                    TaxRate = taxRate;
                }

                public String getCountryOfOriginCode() {
                    return CountryOfOriginCode;
                }

                public void setCountryOfOriginCode(String countryOfOriginCode) {
                    CountryOfOriginCode = countryOfOriginCode;
                }
            }

            // Line-Order
            @XmlRootElement(name = "Line-Order")
            @XmlAccessorType(XmlAccessType.FIELD)
            public static class LineOrder {
                @XmlElement(name = "BuyerOrderNumber")
                private String BuyerOrderNumber;

                public String getBuyerOrderNumber() {
                    return BuyerOrderNumber;
                }

                public void setBuyerOrderNumber(String buyerOrderNumber) {
                    BuyerOrderNumber = buyerOrderNumber;
                }
            }

        }

    }

    // DespatchAdvice-Summary
    @XmlRootElement(name = "DespatchAdvice-Summary")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class DespatchAdviceSummary {

        @XmlElement(name = "TotalAmount")
        private String TotalAmount;
        @XmlElement(name = "TotalQuantity")
        private String TotalQuantity;
        @XmlElement(name = "TotalLines")
        private String TotalLines;
        @XmlElement(name = "TotalGrossAmount")
        private String TotalGrossAmount;
        @XmlElement(name = "TotalTaxAmount")
        private String TotalTaxAmount;

        public String getTotalAmount() {
            return TotalAmount;
        }

        public void setTotalAmount(String totalAmount) {
            TotalAmount = totalAmount;
        }

        public String getTotalQuantity() {
            return TotalQuantity;
        }

        public void setTotalQuantity(String totalQuantity) {
            TotalQuantity = totalQuantity;
        }

        public String getTotalLines() {
            return TotalLines;
        }

        public void setTotalLines(String totalLines) {
            TotalLines = totalLines;
        }

        public String getTotalGrossAmount() {
            return TotalGrossAmount;
        }

        public void setTotalGrossAmount(String totalGrossAmount) {
            TotalGrossAmount = totalGrossAmount;
        }

        public String getTotalTaxAmount() {
            return TotalTaxAmount;
        }

        public void setTotalTaxAmount(String totalTaxAmount) {
            TotalTaxAmount = totalTaxAmount;
        }
    }


}
