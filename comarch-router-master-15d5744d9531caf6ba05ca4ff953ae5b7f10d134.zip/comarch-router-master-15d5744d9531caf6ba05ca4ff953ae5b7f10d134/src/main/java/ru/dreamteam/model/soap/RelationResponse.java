package ru.dreamteam.model.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "relation-response")
@XmlAccessorType(XmlAccessType.FIELD)
public class RelationResponse {

    @XmlElement(name = "relation")
    private List<Relation> relations;

    public List<Relation> getRelations() {
        return relations;
    }

    public void setRelations(List<Relation> relations) {
        this.relations = relations;
    }

    @XmlRootElement(name = "relation")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class Relation {

        @XmlElement(name = "relation-id")
        private String relationsId;
        @XmlElement(name = "partner-iln")
        private String partnerIln;
        @XmlElement(name = "partner-name")
        private String partnerName;
        @XmlElement(name = "direction")
        private String direction;
        @XmlElement(name = "document-type")
        private String documentType;
        @XmlElement(name = "document-version")
        private String documentVersion;
        @XmlElement(name = "document-standard")
        private String documentStandard;
        @XmlElement(name = "document-test")
        private String documentTest;
        @XmlElement(name = "description")
        private String description;
        @XmlElement(name = "test")
        private String test;

        public String getRelationsId() {
            return relationsId;
        }

        public void setRelationsId(String relationsId) {
            this.relationsId = relationsId;
        }

        public String getPartnerIln() {
            return partnerIln;
        }

        public void setPartnerIln(String partnerIln) {
            this.partnerIln = partnerIln;
        }

        public String getPartnerName() {
            return partnerName;
        }

        public void setPartnerName(String partnerName) {
            this.partnerName = partnerName;
        }

        public String getDirection() {
            return direction;
        }

        public void setDirection(String direction) {
            this.direction = direction;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getDocumentVersion() {
            return documentVersion;
        }

        public void setDocumentVersion(String documentVersion) {
            this.documentVersion = documentVersion;
        }

        public String getDocumentStandard() {
            return documentStandard;
        }

        public void setDocumentStandard(String documentStandard) {
            this.documentStandard = documentStandard;
        }

        public String getDocumentTest() {
            return documentTest;
        }

        public void setDocumentTest(String documentTest) {
            this.documentTest = documentTest;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getTest() {
            return test;
        }

        public void setTest(String test) {
            this.test = test;
        }
    }


}
