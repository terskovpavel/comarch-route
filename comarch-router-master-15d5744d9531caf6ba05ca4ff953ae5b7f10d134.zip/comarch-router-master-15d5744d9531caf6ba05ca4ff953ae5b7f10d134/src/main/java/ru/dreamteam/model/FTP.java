package ru.dreamteam.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ftp")
public class FTP {

    private String id;
    private String supplierId;
    private String ip;
    private String department;
    private String login;
    private String password;

    public FTP() {
    }

    public FTP(String ip, String department, String login, String password, String supplierId) {
        this.ip = ip;
        this.department = department;
        this.login = login;
        this.password = password;
        this.supplierId = supplierId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "FTP{" +
                "id='" + id + '\'' +
                ", ip='" + ip + '\'' +
                ", department='" + department + '\'' +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
