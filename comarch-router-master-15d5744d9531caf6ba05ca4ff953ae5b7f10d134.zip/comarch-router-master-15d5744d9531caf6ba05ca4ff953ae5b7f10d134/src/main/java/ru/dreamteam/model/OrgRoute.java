package ru.dreamteam.model;

import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "org_route")
public class OrgRoute {

    private String id;
    private String tsId;
    private String supplierId;
    private Date creationDate;
    private String userName;
    private String comment;
    private List<OrgRoute.DocType> docTypes;

    public OrgRoute() {
    }

    public OrgRoute(String tsId, String supplierId, Date creationDate, String comment, List<DocType> docTypes,String userName) {
        this.tsId = tsId;
        this.supplierId = supplierId;
        this.creationDate = creationDate;
        this.comment = comment;
        this.docTypes = docTypes;
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<DocType> getDocTypes() {
        return docTypes;
    }

    public void setDocTypes(List<DocType> docTypes) {
        this.docTypes = docTypes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTsId() {
        return tsId;
    }

    public void setTsId(String tsId) {
        this.tsId = tsId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }


    @Override
    public String toString() {
        return "OrgRoute{" +
                "id='" + id + '\'' +
                ", tsId='" + tsId + '\'' +
                ", supplierId='" + supplierId + '\'' +
                ", creationDate=" + creationDate +
                ", comment='" + comment + '\'' +
                '}';
    }

    public enum DocType {
        ORDERS, ORDERSP, DESADV_OUT, DESADV_IN, RECADV_OUT, RECADV_IN
    }
}
