package ru.dreamteam.model.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "mailbox-response")
@XmlAccessorType(XmlAccessType.FIELD)
public class MailboxResponse {

    @XmlElement(name = "document-info")
    List<DocumentInfo> documentInfos;

    public List<DocumentInfo> getDocumentInfos() {
        return documentInfos;
    }

    public void setDocumentInfos(List<DocumentInfo> documentInfos) {
        this.documentInfos = documentInfos;
    }

    @XmlRootElement(name = "document-info")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class DocumentInfo {

        @XmlElement(name = "partner-iln")
        private String partnerI1n;
        @XmlElement(name = "tracking-id")
        private String trackingId;
        @XmlElement(name = "document-type")
        private String documentType;
        @XmlElement(name = "document-version")
        private String documentVersion;
        @XmlElement(name = "document-standard")
        private String documentStandard;
        @XmlElement(name = "document-test")
        private String documentTest;
        @XmlElement(name = "document-status")
        private String documentStatus;
        @XmlElement(name = "document-number")
        private String documentNumber;
        @XmlElement(name = "document-date")
        private String documentDate;
        @XmlElement(name = "document-control-number")
        private String documentControlNumber;
        @XmlElement(name = "receive-date")
        private String receiveDate;

        public String getPartnerI1n() {
            return partnerI1n;
        }

        public void setPartnerI1n(String partnerI1n) {
            this.partnerI1n = partnerI1n;
        }

        public String getTrackingId() {
            return trackingId;
        }

        public void setTrackingId(String trackingId) {
            this.trackingId = trackingId;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getDocumentVersion() {
            return documentVersion;
        }

        public void setDocumentVersion(String documentVersion) {
            this.documentVersion = documentVersion;
        }

        public String getDocumentStandard() {
            return documentStandard;
        }

        public void setDocumentStandard(String documentStandard) {
            this.documentStandard = documentStandard;
        }

        public String getDocumentTest() {
            return documentTest;
        }

        public void setDocumentTest(String documentTest) {
            this.documentTest = documentTest;
        }

        public String getDocumentStatus() {
            return documentStatus;
        }

        public void setDocumentStatus(String documentStatus) {
            this.documentStatus = documentStatus;
        }

        public String getDocumentNumber() {
            return documentNumber;
        }

        public void setDocumentNumber(String documentNumber) {
            this.documentNumber = documentNumber;
        }

        public String getDocumentDate() {
            return documentDate;
        }

        public void setDocumentDate(String documentDate) {
            this.documentDate = documentDate;
        }

        public String getDocumentControlNumber() {
            return documentControlNumber;
        }

        public void setDocumentControlNumber(String documentControlNumber) {
            this.documentControlNumber = documentControlNumber;
        }

        public String getReceiveDate() {
            return receiveDate;
        }

        public void setReceiveDate(String receiveDate) {
            this.receiveDate = receiveDate;
        }
    }

}
