package ru.dreamteam.model.ftp;

import ru.dreamteam.model.ftp.xml.DesAdv;

public class FtpDesAdvContainer {

    private DesAdv desAdv;
    private FTPInfo ftpInfo;

    public FtpDesAdvContainer() {
    }

    public FtpDesAdvContainer(DesAdv desAdv, FTPInfo ftpInfo) {
        this.desAdv = desAdv;
        this.ftpInfo = ftpInfo;
    }

    public DesAdv getDesAdv() {
        return desAdv;
    }

    public void setDesAdv(DesAdv desAdv) {
        this.desAdv = desAdv;
    }

    public FTPInfo getFtpInfo() {
        return ftpInfo;
    }

    public void setFtpInfo(FTPInfo ftpInfo) {
        this.ftpInfo = ftpInfo;
    }
}
