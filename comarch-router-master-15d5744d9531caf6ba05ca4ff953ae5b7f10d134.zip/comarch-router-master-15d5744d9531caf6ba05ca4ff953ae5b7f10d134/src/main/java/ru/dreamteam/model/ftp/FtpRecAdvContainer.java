package ru.dreamteam.model.ftp;

import ru.dreamteam.model.ftp.xml.RecAdv;

public class FtpRecAdvContainer {

    private RecAdv recAdv;
    private FTPInfo ftpInfo;

    public FtpRecAdvContainer() {
    }

    public FtpRecAdvContainer(RecAdv recAdv, FTPInfo ftpInfo) {
        this.recAdv = recAdv;
        this.ftpInfo = ftpInfo;
    }

    public RecAdv getRecAdv() {
        return recAdv;
    }

    public void setRecAdv(RecAdv recAdv) {
        this.recAdv = recAdv;
    }

    public FTPInfo getFtpInfo() {
        return ftpInfo;
    }

    public void setFtpInfo(FTPInfo ftpInfo) {
        this.ftpInfo = ftpInfo;
    }
}
