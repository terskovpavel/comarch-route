package ru.dreamteam.config;

import freemarker.cache.WebappTemplateLoader;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;

import javax.servlet.ServletContext;

@Configuration
@EnableWebMvc
@Import({ru.dreamteam.config.PropertySourceConfig.class})
@ComponentScan(basePackages = {"ru.dreamteam.api","ru.dreamteam.controller"})
public class WebConfig extends WebMvcConfigurerAdapter {

    @Autowired(required = false)
    private ServletContext servletContext;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
    }

    @Bean
    public FreeMarkerViewResolver freeMarkerViewResolver() {
        FreeMarkerViewResolver fvr = new FreeMarkerViewResolver();
        fvr.setCache(false);
        fvr.setPrefix("");
        fvr.setSuffix(".ftl");
        fvr.setRequestContextAttribute("rc");
        fvr.setContentType("text/html; charset=UTF-8");
        return fvr;
    }

    @Bean
    public FreeMarkerConfigurer freeMarkerConfigurer() {

        freemarker.template.Configuration configuration =
                new freemarker.template.Configuration(freemarker.template.Configuration.VERSION_2_3_23);
        configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        configuration.setAPIBuiltinEnabled(true);
        configuration.setDefaultEncoding("utf-8");
        configuration.setTemplateLoader(new WebappTemplateLoader(servletContext, "/WEB-INF/view"));

        FreeMarkerConfigurer fmc = new FreeMarkerConfigurer();
        fmc.setConfiguration(configuration);

        return fmc;
    }

    @Bean
    public CommonsMultipartResolver multipartResolver(){
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        return resolver;
    }
}

