package ru.dreamteam.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Обрабатывает событие удачного выхода через /logout
 */
@Component
public class HttpLogoutSuccessHandler implements LogoutSuccessHandler {

    @Override
    public void onLogoutSuccess(HttpServletRequest httpServletRequest,
                                HttpServletResponse httpServletResponse,
                                Authentication authentication) throws IOException, ServletException {

        Cookie sessionIdCookie = new Cookie("JSESSIONID", null);
        sessionIdCookie.setPath(httpServletRequest.getContextPath());
        sessionIdCookie.setMaxAge(0);
        httpServletResponse.addCookie(sessionIdCookie);
        httpServletResponse.sendRedirect("/");
    }

}
