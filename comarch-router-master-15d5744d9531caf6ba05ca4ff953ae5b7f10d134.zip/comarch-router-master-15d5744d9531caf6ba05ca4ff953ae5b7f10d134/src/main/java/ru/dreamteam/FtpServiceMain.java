package ru.dreamteam;

import ru.dreamteam.service.FtpService;
import ru.dreamteam.service.impl.FtpServiceImpl;

import java.io.FileNotFoundException;

/**
 * Класс для тестов
 */
public class FtpServiceMain {

    public static void main(String[] args) throws FileNotFoundException {

        FtpService ftpService = new FtpServiceImpl();

        // FTP server info
        String hostname = "95.85.40.95";
        int port = 21;
        String username = "sandbox";
        String password = "ptV1lU3nQlKLFkQOJtyf";

//        ftpService.downloadFile(hostname, port, username, password, "/test1.txt",
//                "C:\\Users\\vampi\\Workspace\\web-service-xml\\xml_web_service\\test1.txt");
//
//        ftpService.uploadFile(hostname, port, username, password,
//                "C:\\Users\\vampi\\Workspace\\web-service-xml\\xml_web_service\\test2.txt", "/test2.txt");
//
//        ftpService.uploadString(hostname, port, username, password, "Hello, Mothefuckers!!!",
//                "C:\\Users\\vampi\\Workspace\\web-service-xml\\xml_web_service\\tmp.txt", "/test3.txt");
//
//        ftpService.downloadFilesAsStrings(hostname, port, username, password, "/test");
//
//        ftpService.removeFilesInDir(hostname, port, username, password, "/recadv_cp");
//
//        List<RecAdv> recAdvList = ftpService.downloadRecAdvs(hostname, port, username, password, "/recadv");
//
//        List<OrdRes> ordResList = ftpService.downloadOrdReses(hostname, port, username, password, "/ordres");
//
//        List<FTPInfo> ftpInfos = ftpService.downloadFtpInfos(hostname, port, username, password, "/tmp");
//
//        ftpService.removeFileInDir(hostname, port, username, password, "/tmp", "file_1.txt");
//
//        List<DesAdv> desAdvs = ftpService.downloadDesAdvs(hostname, port, username, password, "/desadv");

        String documentIdFromFilename = ftpService.getDocumentIdFromFilename("desadv_EDIEx_0289749.xml");
    }

}
